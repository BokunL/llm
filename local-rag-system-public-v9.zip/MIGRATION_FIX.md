# Database Migration Fix - Version 4.0

## Problem

Beim Docker-Start wurde die Fehlermeldung angezeigt:
```
Table 'local_rag_db.documentChunks' doesn't exist
```

Dies passierte, weil die Drizzle-Migrationen nicht automatisch beim Docker-Start ausgeführt wurden.

## Lösung

### 1. **Entrypoint-Skript** (`scripts/entrypoint.sh`)
- Wartet auf MySQL-Verfügbarkeit
- Führt Drizzle-Migrationen aus
- Startet die Anwendung

### 2. **Dockerfile Update**
- Kopiert `scripts/` Verzeichnis
- Installiert `netcat` für Healthchecks
- Macht `entrypoint.sh` ausführbar
- Nutzt `ENTRYPOINT` statt `CMD`

### 3. **docker-compose.yml Update**
- Fügt `HUGGINGFACE_API_KEY` hinzu (mit Default-Wert)
- Fügt `DB_HOST` und `DB_PORT` hinzu (für entrypoint.sh)
- MySQL `depends_on` mit `service_healthy` Bedingung

## Workflow beim Docker-Start

```
1. Docker startet alle Services (MySQL, MinIO, Ollama)
2. entrypoint.sh wartet auf MySQL
3. Drizzle-Migrationen werden ausgeführt
4. Alle Tabellen werden erstellt
5. Anwendung startet normal
```

## Verwendung

### Neue Umgebungsvariablen

```bash
# Erforderlich: Hugging Face API Key
export HUGGINGFACE_API_KEY=hf_xxxxxxxxxxxxxxxxxxxx

# Docker Compose starten
docker-compose up -d
```

### Logs überprüfen

```bash
# Migrations-Logs anschauen
docker logs local-rag-app | grep -i migration

# Vollständige Logs
docker logs local-rag-app
```

## Troubleshooting

### "Migrations failed"
```bash
# Überprüfen Sie, dass MySQL läuft
docker-compose ps

# MySQL Logs anschauen
docker logs local-rag-mysql

# MySQL manuell neustarten
docker-compose restart mysql
```

### "Connection refused"
```bash
# Erhöhen Sie den Timeout in entrypoint.sh
# Ändern Sie max_attempts von 30 auf 60
```

### "Table still doesn't exist"
```bash
# Führen Sie Migrationen manuell aus
docker exec -it local-rag-app pnpm exec drizzle-kit migrate

# Überprüfen Sie die Datenbank
docker exec -it local-rag-mysql mysql -u rag_user -p local_rag_db -e "SHOW TABLES;"
```

## Dateien geändert

```
✏️  scripts/entrypoint.sh           - Neues Startup-Skript
✏️  scripts/migrate.mjs             - Migrations-Utility
✏️  Dockerfile                      - Kopiert scripts, nutzt ENTRYPOINT
✏️  docker-compose.yml              - Fügt HUGGINGFACE_API_KEY hinzu
✏️  MIGRATION_FIX.md                - Diese Dokumentation
```

## Sicherheit

⚠️ **Wichtig:** Ändern Sie folgende Werte vor Produktiveinsatz:

- `MYSQL_ROOT_PASSWORD` in docker-compose.yml
- `MYSQL_PASSWORD` in docker-compose.yml
- `MINIO_ROOT_PASSWORD` in docker-compose.yml
- `JWT_SECRET` in docker-compose.yml
- `HUGGINGFACE_API_KEY` (setzen Sie Ihren echten Token)

## Nächste Schritte

1. **Vollständig offline:** Ersetzen Sie Hugging Face durch lokale Sentence Transformers
2. **Backup-Strategie:** Richten Sie automatische MySQL-Backups ein
3. **Monitoring:** Implementieren Sie Health-Checks und Logging

---

**Version:** 4.0.0
**Datum:** Februar 2, 2026
**Status:** Produktionsreif ✅
