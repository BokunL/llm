#!/bin/bash

set -e

echo "[Entrypoint] Starting Local RAG System..."
echo "[Entrypoint] Environment: $NODE_ENV"

# Wait for MySQL to be ready
echo "[Entrypoint] Waiting for MySQL to be ready..."
max_attempts=30
attempt=0

while [ $attempt -lt $max_attempts ]; do
  if nc -z ${DB_HOST:-localhost} ${DB_PORT:-3306} 2>/dev/null; then
    echo "[Entrypoint] ✅ MySQL is ready"
    break
  fi
  
  attempt=$((attempt + 1))
  echo "[Entrypoint] MySQL not ready yet... (attempt $attempt/$max_attempts)"
  sleep 2
done

if [ $attempt -eq $max_attempts ]; then
  echo "[Entrypoint] ❌ MySQL failed to start"
  exit 1
fi

# Run database migrations
echo "[Entrypoint] Running database migrations..."
pnpm exec drizzle-kit migrate

if [ $? -ne 0 ]; then
  echo "[Entrypoint] ❌ Database migrations failed"
  exit 1
fi

echo "[Entrypoint] ✅ Database migrations completed"

# Start the application
echo "[Entrypoint] Starting application..."
exec node dist/index.js
