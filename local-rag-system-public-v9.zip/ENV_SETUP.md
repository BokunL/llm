# Umgebungsvariablen Setup

## Erforderliche Variablen

### Datenbank
```bash
DATABASE_URL=mysql://rag_user:rag_password_change_me@localhost:3306/rag_db
```

### Hugging Face API (für Embeddings)
```bash
HUGGINGFACE_API_KEY=hf_xxxxxxxxxxxxxxxxxxxx
```

Besorgen Sie sich einen Token von: https://huggingface.co/settings/tokens

### Ollama LLM Configuration
```bash
OLLAMA_BASE_URL=http://localhost:11434
OLLAMA_MODEL=mistral
```

### S3/MinIO Storage
```bash
AWS_ACCESS_KEY_ID=minioadmin
AWS_SECRET_ACCESS_KEY=minioadmin_change_me
AWS_S3_BUCKET=rag-documents
AWS_S3_REGION=us-east-1
AWS_S3_ENDPOINT=http://localhost:9000
```

### JWT Secret
```bash
JWT_SECRET=your-secret-key-change-this
```

Generieren Sie einen sicheren Secret mit:
```bash
openssl rand -base64 32
```

## Optional: OAuth (nicht erforderlich für öffentliche Deployment)

```bash
OAUTH_SERVER_URL=
VITE_OAUTH_PORTAL_URL=
```

## Optional: Analytics

```bash
VITE_ANALYTICS_ENDPOINT=
VITE_ANALYTICS_WEBSITE_ID=
```

## Application

```bash
NODE_ENV=production
PORT=3000
```

## Docker Compose Setup

Die `docker-compose.yml` enthält bereits Standard-Werte für lokale Entwicklung. Für Produktiveinsatz ändern Sie:

1. **MySQL Passwort** in `docker-compose.yml`
2. **MinIO Credentials** in `docker-compose.yml`
3. **HUGGINGFACE_API_KEY** in `.env.local`

## Sicherheit

⚠️ **WICHTIG:** Ändern Sie folgende Standard-Werte vor dem Produktiveinsatz:

- `AWS_SECRET_ACCESS_KEY` (MinIO)
- `JWT_SECRET`
- MySQL Passwort in `docker-compose.yml`

## Troubleshooting

### "HUGGINGFACE_API_KEY not found"
- Erstellen Sie einen Token auf https://huggingface.co/settings/tokens
- Setzen Sie `HUGGINGFACE_API_KEY` in `.env.local` oder docker-compose.yml
- Starten Sie den Server neu

### "Ollama antwortet nicht"
```bash
# Überprüfen Sie Ollama Status
curl http://localhost:11434/api/tags

# Starten Sie Ollama neu
docker-compose restart ollama

# Laden Sie das Modell herunter
docker exec -it local-rag-ollama ollama pull mistral
```

### "Datenbank-Verbindung fehlgeschlagen"
- Überprüfen Sie, dass MySQL läuft: `docker-compose ps`
- Überprüfen Sie die DATABASE_URL
- Starten Sie MySQL neu: `docker-compose restart mysql`
