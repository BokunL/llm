import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Send, MessageSquare, AlertCircle, Copy, Check, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { Streamdown } from "streamdown";
import { useDocuments } from "@/contexts/DocumentContext";
import { trpc } from "@/lib/trpc";

interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  sources?: Array<{ id: number; text: string; similarity: number }>;
  timestamp: Date;
}

export default function ChatPage() {
  const { documents } = useDocuments();
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages]);

  const queryMutation = trpc.chat.query.useMutation();

  const handleSendMessage = async () => {
    if (!input.trim()) return;

    if (documents.length === 0) {
      toast.error("Bitte laden Sie zuerst ein Dokument hoch");
      return;
    }

    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content: input,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput("");
    setIsLoading(true);

    try {
      // Call RAG query via tRPC
      const response = await queryMutation.mutateAsync({
        question: userMessage.content,
        documentIds: documents.map((d) => d.id),
      });

      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: response.answer,
        sources: response.sources,
        timestamp: new Date(),
      };

      setMessages((prev) => [...prev, assistantMessage]);
      toast.success("Antwort generiert");
    } catch (error) {
      console.error("Error in RAG query:", error);
      toast.error("Fehler beim Generieren der Antwort");
    } finally {
      setIsLoading(false);
    }
  };

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Info Card */}
      {messages.length === 0 && (
        <Card className="bg-gradient-to-br from-blue-50 to-cyan-50 border-blue-200">
          <CardContent className="py-6">
            <div className="flex items-start gap-4">
              <MessageSquare className="w-5 h-5 text-blue-600 mt-1 flex-shrink-0" />
              <div>
                <h3 className="font-semibold text-blue-900 mb-1">Willkommen im Chat</h3>
                <p className="text-sm text-blue-800">
                  {documents.length === 0
                    ? "Laden Sie zunächst Dokumente hoch, dann können Sie Fragen dazu stellen."
                    : `Sie haben ${documents.length} Dokument${documents.length > 1 ? "e" : ""} hochgeladen. Stellen Sie Fragen dazu!`}
                  Das System findet relevante Textpassagen und beantwortet Ihre Fragen basierend auf dem Inhalt.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Messages */}
      <ScrollArea className="h-[500px] border rounded-lg p-4 bg-white">
        <div className="space-y-4">
          {messages.length === 0 ? (
            <div className="flex items-center justify-center h-full text-gray-400">
              <p>Keine Nachrichten. Stellen Sie eine Frage, um zu beginnen.</p>
            </div>
          ) : (
            messages.map((message) => (
              <div
                key={message.id}
                className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}
              >
                <div
                  className={`max-w-[70%] rounded-lg p-3 ${
                    message.role === "user"
                      ? "bg-blue-500 text-white"
                      : "bg-gray-100 text-gray-900"
                  }`}
                >
                  <div className="text-sm">
                    <Streamdown>{message.content}</Streamdown>
                  </div>

                  {/* Sources */}
                  {message.sources && message.sources.length > 0 && (
                    <div className="mt-3 pt-3 border-t border-gray-300">
                      <p className="text-xs font-semibold mb-2">Quellen:</p>
                      {message.sources.map((source) => (
                        <div
                          key={source.id}
                          className="text-xs bg-white bg-opacity-20 p-2 rounded mb-1 cursor-pointer hover:bg-opacity-30 transition"
                          onClick={() => copyToClipboard(source.text, source.id.toString())}
                        >
                          <div className="flex items-center justify-between">
                            <span className="truncate">{source.text}</span>
                            {copiedId === source.id.toString() ? (
                              <Check className="w-3 h-3 ml-2 flex-shrink-0" />
                            ) : (
                              <Copy className="w-3 h-3 ml-2 flex-shrink-0" />
                            )}
                          </div>
                          <div className="text-xs opacity-75 mt-1">
                            Ähnlichkeit: {(source.similarity * 100).toFixed(0)}%
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            ))
          )}
          {isLoading && (
            <div className="flex justify-start">
              <div className="bg-gray-100 text-gray-900 rounded-lg p-3 flex items-center gap-2">
                <Loader2 className="w-4 h-4 animate-spin" />
                <span className="text-sm">Generiere Antwort...</span>
              </div>
            </div>
          )}
          <div ref={scrollRef} />
        </div>
      </ScrollArea>

      {/* Input */}
      <div className="flex gap-2">
        <Input
          placeholder="Stellen Sie eine Frage zu Ihren Dokumenten..."
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyPress={(e) => {
            if (e.key === "Enter" && !isLoading) {
              handleSendMessage();
            }
          }}
          disabled={isLoading}
          className="flex-1"
        />
        <Button
          onClick={handleSendMessage}
          disabled={isLoading || !input.trim()}
          className="gap-2"
        >
          {isLoading ? (
            <Loader2 className="w-4 h-4 animate-spin" />
          ) : (
            <Send className="w-4 h-4" />
          )}
        </Button>
      </div>

      {/* Help Text */}
      <p className="text-xs text-gray-500 text-center">
        Drücken Sie Enter zum Senden oder klicken Sie auf den Button
      </p>
    </div>
  );
}
