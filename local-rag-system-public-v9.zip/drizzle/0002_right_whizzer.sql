ALTER TABLE `documents` DROP FOREIGN KEY `documents_userId_users_id_fk`;
--> statement-breakpoint
ALTER TABLE `documents` MODIFY COLUMN `userId` int DEFAULT 0;--> statement-breakpoint
ALTER TABLE `documents` MODIFY COLUMN `userId` int;