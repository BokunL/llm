# Local RAG System - Deployment & Setup Guide

## Überblick

Das Local RAG System ist eine vollständig lokale Retrieval-Augmented Generation (RAG) Anwendung, die es Benutzern ermöglicht, Dokumente hochzuladen und intelligente Fragen dazu zu stellen. Das System benötigt keine Cloud-APIs und läuft vollständig auf lokalen Ressourcen.

## Systemanforderungen

### Minimum-Anforderungen
- **CPU:** 6-8 Kerne (empfohlen für LLM-Inferenz)
- **RAM:** 16 GB (4 GB für Ollama LLM, 8 GB für Embeddings und Anwendung)
- **Speicher:** 20-50 GB SSD (für Modelle und Datenbank)
- **Betriebssystem:** Linux (Ubuntu 20.04+), macOS, oder Windows mit WSL2

### Empfohlene Anforderungen
- **CPU:** 8+ Kerne
- **RAM:** 32 GB
- **Speicher:** 100+ GB SSD
- **GPU:** Optional (NVIDIA mit CUDA für schnellere Inferenz)

## Komponenten

### 1. Frontend
- **Framework:** React 19 + Tailwind CSS 4
- **Port:** 3000 (Standard)
- **Build:** Vite

### 2. Backend
- **Framework:** Express 4 + tRPC 11
- **Database:** MySQL/TiDB
- **Port:** 3000 (integriert mit Frontend)

### 3. LLM Runtime
- **Ollama:** Lokaler LLM-Server
- **Port:** 11434 (Standard)
- **Modell:** Mistral 7B (Q4 quantisiert, ~4GB RAM)

### 4. Embeddings
- **Service:** Manus Forge API oder lokale Alternative
- **Modell:** sentence-transformers/all-MiniLM-L6-v2
- **Dimension:** 384

### 5. Datenspeicherung
- **Vektoren:** MySQL (als JSON-Felder)
- **Dateien:** S3-kompatible Speicherung (MinIO oder AWS S3)
- **Metadaten:** MySQL

## Pre-Deployment Checkliste

- [ ] Linux/macOS/Windows WSL2 System verfügbar
- [ ] Docker und Docker Compose installiert (empfohlen)
- [ ] Node.js 22+ und pnpm installiert
- [ ] MySQL 8.0+ oder MariaDB 10.5+ verfügbar
- [ ] Ollama heruntergeladen und installiert
- [ ] Mindestens 50 GB freier Speicherplatz
- [ ] Internetzugang für initiale Modell-Downloads

## Installation & Deployment

### Option 1: Docker Compose (Empfohlen)

#### Schritt 1: Docker Compose Datei erstellen

Erstellen Sie eine `docker-compose.yml` im Projektverzeichnis:

```yaml
version: '3.8'

services:
  # MySQL Datenbank
  mysql:
    image: mysql:8.0
    container_name: local-rag-mysql
    environment:
      MYSQL_ROOT_PASSWORD: root_password_change_me
      MYSQL_DATABASE: local_rag_db
      MYSQL_USER: rag_user
      MYSQL_PASSWORD: rag_password_change_me
    ports:
      - "3306:3306"
    volumes:
      - mysql_data:/var/lib/mysql
    healthcheck:
      test: ["CMD", "mysqladmin", "ping", "-h", "localhost"]
      timeout: 5s
      retries: 10

  # MinIO S3-kompatible Speicherung
  minio:
    image: minio/minio:latest
    container_name: local-rag-minio
    environment:
      MINIO_ROOT_USER: minioadmin
      MINIO_ROOT_PASSWORD: minioadmin_change_me
    ports:
      - "9000:9000"
      - "9001:9001"
    volumes:
      - minio_data:/minio_data
    command: server /minio_data --console-address ":9001"
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:9000/minio/health/live"]
      timeout: 5s
      retries: 10

  # Ollama LLM Server
  ollama:
    image: ollama/ollama:latest
    container_name: local-rag-ollama
    ports:
      - "11434:11434"
    volumes:
      - ollama_data:/root/.ollama
    environment:
      - OLLAMA_HOST=0.0.0.0:11434
    # GPU-Unterstützung (optional)
    # deploy:
    #   resources:
    #     reservations:
    #       devices:
    #         - driver: nvidia
    #           count: 1
    #           capabilities: [gpu]

  # RAG Application
  app:
    build:
      context: .
      dockerfile: Dockerfile
    container_name: local-rag-app
    depends_on:
      mysql:
        condition: service_healthy
      minio:
        condition: service_healthy
      ollama:
        condition: service_started
    environment:
      NODE_ENV: production
      DATABASE_URL: mysql://rag_user:rag_password_change_me@mysql:3306/local_rag_db
      S3_ENDPOINT: http://minio:9000
      S3_ACCESS_KEY: minioadmin
      S3_SECRET_KEY: minioadmin_change_me
      S3_BUCKET: rag-documents
      OLLAMA_BASE_URL: http://ollama:11434
      JWT_SECRET: your_jwt_secret_change_me
      VITE_APP_ID: local-rag-app
    ports:
      - "3000:3000"
    volumes:
      - ./uploads:/app/uploads

volumes:
  mysql_data:
  minio_data:
  ollama_data:
```

#### Schritt 2: Dockerfile erstellen

Erstellen Sie ein `Dockerfile` im Projektverzeichnis:

```dockerfile
FROM node:22-alpine

WORKDIR /app

# Installiere pnpm
RUN npm install -g pnpm

# Kopiere package.json und lock-Dateien
COPY package.json pnpm-lock.yaml ./

# Installiere Abhängigkeiten
RUN pnpm install --frozen-lockfile

# Kopiere Quellcode
COPY . .

# Baue die Anwendung
RUN pnpm build

# Starte die Anwendung
EXPOSE 3000
CMD ["pnpm", "start"]
```

#### Schritt 3: Docker Compose starten

```bash
# Navigiere zum Projektverzeichnis
cd /path/to/local-rag-system

# Starte alle Services
docker-compose up -d

# Überprüfe den Status
docker-compose ps

# Logs anschauen
docker-compose logs -f app
```

#### Schritt 4: Ollama Modelle herunterladen

```bash
# Verbinde dich mit Ollama Container
docker exec -it local-rag-ollama ollama pull mistral

# Überprüfe verfügbare Modelle
docker exec -it local-rag-ollama ollama list
```

#### Schritt 5: MinIO Bucket erstellen

```bash
# Öffne MinIO Console im Browser
# http://localhost:9001
# Anmelden mit: minioadmin / minioadmin_change_me
# Erstelle einen Bucket namens "rag-documents"
```

### Option 2: Manuelle Installation (Linux/macOS)

#### Schritt 1: Abhängigkeiten installieren

```bash
# Node.js 22+ (falls nicht vorhanden)
curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -
sudo apt-get install -y nodejs

# pnpm
npm install -g pnpm

# MySQL Server
sudo apt-get install -y mysql-server

# Ollama
curl -fsSL https://ollama.ai/install.sh | sh

# MinIO (optional, für S3-kompatible Speicherung)
wget https://dl.min.io/server/minio/release/linux-amd64/minio
chmod +x minio
sudo mv minio /usr/local/bin/
```

#### Schritt 2: Datenbank konfigurieren

```bash
# MySQL starten
sudo systemctl start mysql

# Datenbank und Benutzer erstellen
mysql -u root -p << EOF
CREATE DATABASE local_rag_db;
CREATE USER 'rag_user'@'localhost' IDENTIFIED BY 'rag_password_change_me';
GRANT ALL PRIVILEGES ON local_rag_db.* TO 'rag_user'@'localhost';
FLUSH PRIVILEGES;
EOF
```

#### Schritt 3: Ollama starten

```bash
# Ollama im Hintergrund starten
ollama serve &

# Modell herunterladen (in separatem Terminal)
ollama pull mistral

# Überprüfe ob Ollama läuft
curl http://localhost:11434/api/tags
```

#### Schritt 4: MinIO starten (optional)

```bash
# MinIO Datenverzeichnis erstellen
mkdir -p ~/minio-data

# MinIO starten
minio server ~/minio-data --console-address ":9001" &

# Öffne http://localhost:9001 im Browser
```

#### Schritt 5: RAG-Anwendung installieren und starten

```bash
# Navigiere zum Projektverzeichnis
cd /path/to/local-rag-system

# Installiere Abhängigkeiten
pnpm install

# Erstelle .env Datei
cat > .env.local << EOF
NODE_ENV=production
DATABASE_URL=mysql://rag_user:rag_password_change_me@localhost:3306/local_rag_db
S3_ENDPOINT=http://localhost:9000
S3_ACCESS_KEY=minioadmin
S3_SECRET_KEY=minioadmin_change_me
S3_BUCKET=rag-documents
OLLAMA_BASE_URL=http://localhost:11434
JWT_SECRET=your_jwt_secret_change_me_32_chars_min
VITE_APP_ID=local-rag-app
EOF

# Führe Datenbankmigrationen durch
pnpm db:push

# Baue die Anwendung
pnpm build

# Starte die Anwendung
pnpm start
```

### Option 3: Windows mit WSL2

Folgen Sie den Anweisungen für Linux, aber verwenden Sie WSL2 Terminal:

```bash
# WSL2 öffnen
wsl

# Dann folgen Sie Option 2 (Manuelle Installation)
```

## Konfiguration

### Umgebungsvariablen

Erstellen Sie eine `.env.local` Datei mit folgenden Variablen:

```env
# Datenbank
DATABASE_URL=mysql://user:password@localhost:3306/database_name

# S3 Speicherung
S3_ENDPOINT=http://localhost:9000
S3_ACCESS_KEY=minioadmin
S3_SECRET_KEY=your_secret_key
S3_BUCKET=rag-documents
S3_REGION=us-east-1

# Ollama LLM
OLLAMA_BASE_URL=http://localhost:11434
OLLAMA_MODEL=mistral

# JWT
JWT_SECRET=your_jwt_secret_minimum_32_characters

# Anwendung
NODE_ENV=production
VITE_APP_ID=local-rag-app
VITE_APP_TITLE=Local RAG System
```

### Datenbank-Initialisierung

```bash
# Migrationen durchführen
pnpm db:push

# (Optional) Datenbank zurücksetzen
pnpm db:reset
```

### Ollama Modelle

Verfügbare Modelle:

| Modell | Größe | VRAM | Geschwindigkeit |
|--------|-------|------|-----------------|
| mistral | 7B (Q4) | 4 GB | Schnell |
| llama2 | 7B (Q4) | 4 GB | Schnell |
| neural-chat | 7B (Q4) | 4 GB | Schnell |
| dolphin-mixtral | 8x7B (Q4) | 12 GB | Langsam, besser |

```bash
# Modell herunterladen
ollama pull mistral

# Modell testen
curl -X POST http://localhost:11434/api/generate \
  -d '{"model":"mistral","prompt":"Hello"}'
```

## Zugriff auf die Anwendung

Nach erfolgreichem Start:

- **Frontend:** http://localhost:3000
- **MinIO Console:** http://localhost:9001 (falls verwendet)
- **MySQL:** localhost:3306
- **Ollama API:** http://localhost:11434

## Monitoring & Logs

### Docker Compose

```bash
# Logs aller Services
docker-compose logs -f

# Logs eines spezifischen Services
docker-compose logs -f app

# Services überprüfen
docker-compose ps

# Service neu starten
docker-compose restart app
```

### Manuelle Installation

```bash
# Anwendungs-Logs (wenn mit systemd läuft)
journalctl -u local-rag-app -f

# Ollama Logs
tail -f ~/.ollama/logs/ollama.log

# MySQL Logs
sudo tail -f /var/log/mysql/error.log
```

## Troubleshooting

### Problem: Datenbank-Verbindungsfehler

```bash
# Überprüfe MySQL Status
sudo systemctl status mysql

# Überprüfe Verbindung
mysql -u rag_user -p -h localhost -D local_rag_db -e "SELECT 1;"
```

### Problem: Ollama antwortet nicht

```bash
# Überprüfe ob Ollama läuft
curl http://localhost:11434/api/tags

# Starte Ollama neu
pkill ollama
ollama serve &
```

### Problem: S3 Upload schlägt fehl

```bash
# Überprüfe MinIO
curl http://localhost:9000/minio/health/live

# Überprüfe Bucket
mc ls minio/rag-documents
```

### Problem: Hohe CPU/RAM Auslastung

- Reduzieren Sie die Ollama Modellgröße
- Verwenden Sie quantisierte Modelle (Q4 statt Q8)
- Erhöhen Sie die Systemressourcen

## Sicherheit

### Wichtige Sicherheitsmaßnahmen

1. **Passwörter ändern:**
   ```bash
   # Alle Standard-Passwörter in .env.local ändern
   # MySQL root password
   # MinIO credentials
   # JWT secret
   ```

2. **Firewall konfigurieren:**
   ```bash
   # Nur lokale Verbindungen erlauben
   sudo ufw allow from 127.0.0.1 to any port 3000
   sudo ufw allow from 127.0.0.1 to any port 3306
   sudo ufw allow from 127.0.0.1 to any port 11434
   ```

3. **HTTPS aktivieren:**
   - Verwenden Sie einen Reverse Proxy (nginx, Caddy)
   - Installieren Sie SSL-Zertifikate

4. **Regelmäßige Backups:**
   ```bash
   # MySQL Backup
   mysqldump -u rag_user -p local_rag_db > backup.sql
   
   # S3 Daten Backup
   mc mirror minio/rag-documents ./backup/
   ```

## Performance-Optimierung

### Für schnellere Antworten

1. **Ollama Optimierung:**
   ```bash
   # Erhöhe num_gpu_layers für GPU-Nutzung
   ollama run mistral --num_gpu_layers 40
   ```

2. **Datenbank-Indizes:**
   ```sql
   CREATE INDEX idx_documents_user ON documents(userId);
   CREATE INDEX idx_chunks_document ON documentChunks(documentId);
   CREATE INDEX idx_messages_session ON chatMessages(sessionId);
   ```

3. **Caching aktivieren:**
   - Implementieren Sie Redis für Session-Caching
   - Cachen Sie häufig abgerufene Embeddings

## Wartung

### Regelmäßige Aufgaben

```bash
# Wöchentlich: Logs rotieren
sudo logrotate -f /etc/logrotate.d/local-rag-app

# Monatlich: Datenbank optimieren
mysql -u rag_user -p local_rag_db -e "OPTIMIZE TABLE documents, documentChunks, chatMessages;"

# Monatlich: Alte Chat-Sessions löschen
mysql -u rag_user -p local_rag_db -e "DELETE FROM chatSessions WHERE updatedAt < DATE_SUB(NOW(), INTERVAL 90 DAY);"
```

### Upgrade-Prozess

```bash
# Backup erstellen
docker-compose exec mysql mysqldump -u rag_user -p local_rag_db > backup.sql

# Code aktualisieren
git pull origin main

# Abhängigkeiten aktualisieren
pnpm install

# Migrationen durchführen
pnpm db:push

# Neu bauen und starten
docker-compose up -d --build
```

## Support & Dokumentation

- **Quellcode:** `/path/to/local-rag-system`
- **API-Dokumentation:** Siehe `server/routers.ts`
- **Datenbankschema:** Siehe `drizzle/schema.ts`
- **Frontend-Komponenten:** Siehe `client/src/pages/`

## Kontakt & Support

Bei Fragen oder Problemen:
1. Überprüfen Sie die Logs
2. Konsultieren Sie diesen Guide
3. Überprüfen Sie die Systemanforderungen
4. Kontaktieren Sie das Entwicklungsteam

---

**Letzte Aktualisierung:** Februar 2026
**Version:** 1.0.0
