# LangChain + Hugging Face Integration Guide

## Überblick

Das Local RAG System wurde auf **LangChain** und **Hugging Face Embeddings** migriert. Dies bietet:

- **LangChain:** Robuste RAG-Pipeline mit Text-Splitting und Prompt-Management
- **Hugging Face Embeddings:** Lokale Embedding-Generierung mit `sentence-transformers/all-MiniLM-L6-v2`
- **Ollama:** Lokale LLM-Inferenz für Antwort-Generierung

## Installierte Dependencies

```bash
# LangChain Core & Community
- langchain: 1.2.16
- @langchain/core: 1.1.18
- @langchain/community: 1.1.10
- @langchain/textsplitters: 1.0.1

# Hugging Face
- @huggingface/inference: 4.13.11

# Andere
- dotenv: Für Umgebungsvariablen
```

## Konfiguration

### Erforderliche Umgebungsvariablen

```env
# Hugging Face API Key (erforderlich für Embeddings)
HUGGINGFACE_API_KEY=your_huggingface_api_key

# Ollama Konfiguration
OLLAMA_BASE_URL=http://localhost:11434
OLLAMA_MODEL=mistral
```

### Hugging Face API Key erhalten

1. Besuchen Sie https://huggingface.co/settings/tokens
2. Erstellen Sie einen neuen Token (Read-only ist ausreichend)
3. Kopieren Sie den Token in `HUGGINGFACE_API_KEY`

## Architektur

### Embedding-Pipeline

```
Dokument/Frage
    ↓
[HuggingFaceInferenceEmbeddings]
    ↓
Embedding Vector (384 Dimensionen)
    ↓
Ähnlichkeitssuche (Cosine Similarity)
```

### RAG-Pipeline

```
Benutzer-Frage
    ↓
[Embedding generieren]
    ↓
[Ähnliche Chunks finden]
    ↓
[Kontext zusammenstellen]
    ↓
[Prompt erstellen]
    ↓
[Ollama LLM aufrufen]
    ↓
[Antwort mit Quellen zurückgeben]
```

## Verwendung

### Embedding generieren

```typescript
import { generateEmbedding, generateEmbeddings } from "./server/embeddings";

// Einzelnes Embedding
const embedding = await generateEmbedding("Hallo Welt");

// Mehrere Embeddings
const embeddings = await generateEmbeddings([
  "Text 1",
  "Text 2",
  "Text 3"
]);
```

### Text in Chunks aufteilen

```typescript
import { splitTextIntoChunks } from "./server/embeddings";

const chunks = await splitTextIntoChunks(
  "Langer Text...",
  1000,  // chunk size
  200    // overlap
);
```

### RAG Query durchführen

```typescript
import { ragQuery } from "./server/rag";

const result = await ragQuery(
  "Meine Frage?",
  chunks,  // Array von Chunks mit Embeddings
  5        // maxChunks
);

console.log(result.answer);
console.log(result.sources);
```

## Modelle

### Embedding Modell

**Modell:** `sentence-transformers/all-MiniLM-L6-v2`
- **Größe:** ~22 MB
- **Dimensionen:** 384
- **Geschwindigkeit:** Sehr schnell
- **Qualität:** Gut für allgemeine Zwecke

### Alternative Embedding Modelle

Sie können andere Hugging Face Modelle verwenden, indem Sie `EMBEDDING_MODEL` in `server/embeddings.ts` ändern:

```typescript
// Größere, bessere Qualität
"sentence-transformers/all-mpnet-base-v2"  // 438 MB, 768 dim

// Kleinere, schneller
"sentence-transformers/all-MiniLM-L12-v2"  // 33 MB, 384 dim
```

### LLM Modell (Ollama)

**Standard:** `mistral` (7B, quantisiert Q4)

Andere Optionen:
- `llama2` - 7B, gut für Deutsch
- `neural-chat` - 7B, optimiert für Chat
- `dolphin-mixtral` - 8x7B, besser aber langsamer

## Performance-Tipps

### 1. Embedding-Caching

Speichern Sie Embeddings in der Datenbank, um wiederholte Berechnungen zu vermeiden:

```typescript
// Embedding berechnen und speichern
const embedding = await generateEmbedding(text);
await db.insert(chunks).values({
  text,
  embedding: JSON.stringify(embedding),
});
```

### 2. Batch-Embedding

Verwenden Sie `generateEmbeddings` für mehrere Texte gleichzeitig:

```typescript
// Schneller als einzelne Aufrufe
const embeddings = await generateEmbeddings(texts);
```

### 3. Chunk-Größe optimieren

- **Zu klein (< 200 Zeichen):** Verlust von Kontext
- **Zu groß (> 2000 Zeichen):** Weniger präzise Suche
- **Optimal:** 800-1200 Zeichen mit 200-300 Overlap

### 4. Ähnlichkeitsschwelle

Standardwert: `0.3` (30% Ähnlichkeit)

```typescript
// Höher = strenger (weniger Ergebnisse)
findSimilarChunks(embedding, chunks, 5, 0.5);

// Niedriger = lockerer (mehr Ergebnisse)
findSimilarChunks(embedding, chunks, 5, 0.2);
```

## Troubleshooting

### Problem: "HUGGINGFACE_API_KEY not found"

**Lösung:**
1. Erstellen Sie einen Token auf https://huggingface.co/settings/tokens
2. Setzen Sie `HUGGINGFACE_API_KEY` in `.env.local`
3. Starten Sie den Server neu

### Problem: Langsame Embeddings

**Lösungen:**
- Verwenden Sie ein kleineres Modell (`all-MiniLM-L12-v2`)
- Verwenden Sie Batch-Embedding für mehrere Texte
- Erhöhen Sie die Systemressourcen

### Problem: Ollama antwortet nicht

**Lösung:**
```bash
# Überprüfe Ollama Status
curl http://localhost:11434/api/tags

# Starte Ollama neu
docker-compose restart ollama

# Oder manuell
pkill ollama
ollama serve &
```

### Problem: Schlechte Antwortqualität

**Lösungen:**
1. Verwenden Sie ein besseres LLM-Modell (`dolphin-mixtral`)
2. Erhöhen Sie `maxChunks` in `ragQuery`
3. Optimieren Sie die Chunk-Größe
4. Verwenden Sie ein besseres Embedding-Modell

## Kosten

### Hugging Face API

- **Kostenlos:** Bis zu 30.000 Anfragen/Monat
- **Bezahlt:** Nach Überschreitung

### Ollama

- **Kostenlos:** Vollständig lokal, keine Kosten

## Weitere Ressourcen

- [LangChain Dokumentation](https://python.langchain.com/)
- [Hugging Face Inference API](https://huggingface.co/docs/api-inference)
- [Sentence Transformers](https://www.sbert.net/)
- [Ollama Dokumentation](https://github.com/ollama/ollama)

## Migration von alter Implementierung

Falls Sie von der alten Manus Forge API migrieren:

### Alt (Manus Forge API)
```typescript
import { invokeLLM } from "./_core/llm";
const response = await invokeLLM({ messages: [...] });
```

### Neu (LangChain + Hugging Face)
```typescript
import { ragQuery } from "./rag";
import { generateEmbedding } from "./embeddings";

const embedding = await generateEmbedding(text);
const result = await ragQuery(question, chunks);
```

## Nächste Schritte

1. **Konfigurieren Sie Hugging Face API Key**
2. **Testen Sie Embeddings:** `pnpm test`
3. **Starten Sie die Anwendung:** `docker-compose up -d`
4. **Laden Sie Dokumente hoch und testen Sie RAG**

---

**Version:** 1.0.0
**Datum:** Februar 2026
