/**
 * Document parsing utilities for PDF, TXT, and Markdown files
 */

import { Readable } from "stream";

const CHUNK_SIZE = 1000; // Characters per chunk
const CHUNK_OVERLAP = 200; // Overlap between chunks

export interface ParsedDocument {
  text: string;
  metadata: {
    pageCount?: number;
    format: "pdf" | "txt" | "markdown";
  };
}

/**
 * Parse text file
 */
export async function parseTxt(content: string): Promise<ParsedDocument> {
  return {
    text: content,
    metadata: {
      format: "txt",
    },
  };
}

/**
 * Parse Markdown file
 */
export async function parseMarkdown(content: string): Promise<ParsedDocument> {
  return {
    text: content,
    metadata: {
      format: "markdown",
    },
  };
}

/**
 * Parse PDF file (basic text extraction)
 * For production, consider using pdf-parse or pdfjs-dist
 */
export async function parsePdf(buffer: Buffer): Promise<ParsedDocument> {
  // For now, return a placeholder
  // In production, use a proper PDF parsing library
  const text = buffer.toString("utf-8").replace(/[^\\x20-\\x7E\\n]/g, "");

  return {
    text: text || "Unable to extract text from PDF",
    metadata: {
      format: "pdf",
      pageCount: 1, // Placeholder
    },
  };
}

/**
 * Split text into chunks with overlap
 */
export function chunkText(
  text: string,
  chunkSize: number = CHUNK_SIZE,
  overlap: number = CHUNK_OVERLAP
): string[] {
  const chunks: string[] = [];
  let start = 0;

  while (start < text.length) {
    const end = Math.min(start + chunkSize, text.length);
    chunks.push(text.substring(start, end).trim());

    // Move start position for next chunk with overlap
    start = end - overlap;

    // Avoid infinite loop if text is very short
    if (start <= 0) break;
  }

  return chunks.filter((chunk) => chunk.length > 0);
}

/**
 * Extract metadata from text (simple implementation)
 */
export function extractMetadata(
  text: string,
  chunkIndex: number
): Record<string, any> {
  return {
    chunkIndex,
    charCount: text.length,
    wordCount: text.split(/\\s+/).length,
  };
}

/**
 * Main document parsing function
 */
export async function parseDocument(
  content: Buffer | string,
  mimeType: string
): Promise<ParsedDocument> {
  const contentStr = typeof content === "string" ? content : content.toString("utf-8");

  switch (mimeType) {
    case "text/plain":
      return parseTxt(contentStr);
    case "text/markdown":
      return parseMarkdown(contentStr);
    case "application/pdf":
      return parsePdf(typeof content === "string" ? Buffer.from(content) : content);
    default:
      // Try to parse as plain text
      return parseTxt(contentStr);
  }
}
