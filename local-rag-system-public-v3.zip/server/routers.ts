import { publicProcedure, router } from "./_core/trpc";
import { systemRouter } from "./_core/systemRouter";
import { z } from "zod";
import * as db from "./db";
import { ragQuery } from "./rag";

export const appRouter = router({
  system: systemRouter,
  
  auth: router({
    me: publicProcedure.query(() => null),
    logout: publicProcedure.mutation(() => {
      return {
        success: true,
      } as const;
    }),
  }),

  documents: router({
    list: publicProcedure.query(async () => {
      return db.getAllDocuments();
    }),

    delete: publicProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.deleteDocument(input.id);
        return { success: true };
      }),
  }),

  chat: router({
    createSession: publicProcedure
      .input(z.object({ title: z.string().optional() }))
      .mutation(async ({ input }) => {
        const result = await db.createChatSession({
          userId: 0,
          title: input.title || `Chat ${new Date().toLocaleDateString()}`,
        });
        return result;
      }),

    getSessions: publicProcedure.query(async () => {
      return db.getChatSessionsByUserId(0);
    }),

    getMessages: publicProcedure
      .input(z.object({ sessionId: z.number() }))
      .query(async ({ input }) => {
        const session = await db.getChatSessionById(input.sessionId);
        if (!session) {
          throw new Error("Session not found");
        }
        const messages = await db.getChatMessagesBySessionId(input.sessionId);
        return messages.map((msg) => ({
          ...msg,
          sources: JSON.parse(msg.sources || "[]"),
        }));
      }),

    deleteSession: publicProcedure
      .input(z.object({ sessionId: z.number() }))
      .mutation(async ({ input }) => {
        await db.deleteChatSession(input.sessionId);
        return { success: true };
      }),

    query: publicProcedure
      .input(z.object({
        question: z.string(),
        documentIds: z.array(z.number()).optional(),
      }))
      .mutation(async ({ input }) => {
        try {
          const chunks = await db.getAllChunks();
          
          if (chunks.length === 0) {
            return {
              answer: "Keine Dokumente gefunden. Bitte laden Sie zuerst Dokumente hoch.",
              sources: [],
            };
          }

          const result = await ragQuery(input.question, chunks);
          return result;
        } catch (error) {
          console.error("Error in chat.query:", error);
          throw error;
        }
      }),
  }),
});

export type AppRouter = typeof appRouter;
