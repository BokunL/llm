import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Upload, Trash2, File, Clock, HardDrive, AlertCircle } from "lucide-react";
import { toast } from "sonner";
import { useDocuments } from "@/contexts/DocumentContext";

export default function DocumentsPage() {
  const { documents, addDocument, removeDocument, updateDocument } = useDocuments();
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.currentTarget.files;
    if (!files || files.length === 0) return;

    const file = files[0];
    setIsUploading(true);

    try {
      // TODO: Implement file upload via tRPC
      toast.success(`${file.name} wird hochgeladen...`);
      
      // Simulate upload
      await new Promise((resolve) => setTimeout(resolve, 1000));
      
      const newDoc = {
        id: Date.now(),
        name: file.name,
        size: file.size,
        uploadedAt: new Date(),
        status: "completed" as const,
        chunks: Math.floor(Math.random() * 50) + 10,
      };
      
      addDocument(newDoc);
      
      toast.success("Dokument erfolgreich hochgeladen!");
    } catch (error) {
      toast.error("Fehler beim Hochladen des Dokuments");
    } finally {
      setIsUploading(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = "";
      }
    }
  };

  const handleDelete = (id: number) => {
    removeDocument(id);
    toast.success("Dokument gelöscht");
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return "0 Bytes";
    const k = 1024;
    const sizes = ["Bytes", "KB", "MB", "GB"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return Math.round((bytes / Math.pow(k, i)) * 100) / 100 + " " + sizes[i];
  };

  const formatDate = (date: Date) => {
    return new Date(date).toLocaleDateString("de-DE", {
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  return (
    <div className="space-y-6">
      {/* Upload Section */}
      <Card className="border-2 border-dashed border-border hover:border-accent/50 transition-colors">
        <CardHeader>
          <CardTitle>Dokumente hochladen</CardTitle>
          <CardDescription>
            Laden Sie PDF-, TXT- oder Markdown-Dateien hoch, um sie zu indizieren
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col items-center justify-center py-12 gap-4">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-accent/10">
              <Upload className="w-8 h-8 text-accent" />
            </div>
            <div className="text-center">
              <p className="font-semibold text-foreground mb-1">
                Klicken Sie zum Hochladen oder ziehen Sie Dateien hierher
              </p>
              <p className="text-sm text-muted-foreground">
                Unterstützte Formate: PDF, TXT, Markdown (max. 50MB)
              </p>
            </div>
            <Button
              onClick={() => fileInputRef.current?.click()}
              disabled={isUploading}
              className="mt-4"
            >
              {isUploading ? "Wird hochgeladen..." : "Datei auswählen"}
            </Button>
            <input
              ref={fileInputRef}
              type="file"
              accept=".pdf,.txt,.md,.docx"
              onChange={handleFileSelect}
              disabled={isUploading}
              className="hidden"
            />
          </div>
        </CardContent>
      </Card>

      {/* Documents List */}
      {documents.length > 0 ? (
        <div>
          <h2 className="text-lg font-semibold text-foreground mb-4">
            Hochgeladene Dokumente ({documents.length})
          </h2>
          <div className="space-y-3">
            {documents.map((doc) => (
              <Card key={doc.id} className="hover:shadow-md transition-shadow">
                <CardContent className="py-4">
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex items-start gap-4 flex-1">
                      <div className="flex-shrink-0">
                        <div className="inline-flex items-center justify-center w-10 h-10 rounded-lg bg-accent/10">
                          <File className="w-5 h-5 text-accent" />
                        </div>
                      </div>
                      <div className="flex-1 min-w-0">
                        <h3 className="font-semibold text-foreground truncate">
                          {doc.name}
                        </h3>
                        <div className="flex items-center gap-4 mt-2 text-sm text-muted-foreground flex-wrap">
                          <div className="flex items-center gap-1">
                            <HardDrive className="w-4 h-4" />
                            {formatFileSize(doc.size)}
                          </div>
                          <div className="flex items-center gap-1">
                            <Clock className="w-4 h-4" />
                            {formatDate(doc.uploadedAt)}
                          </div>
                          {doc.status === "processing" && (
                            <div className="flex items-center gap-1 text-accent">
                              <div className="w-2 h-2 rounded-full bg-accent animate-pulse" />
                              Wird verarbeitet...
                            </div>
                          )}
                          {doc.status === "completed" && (
                            <div className="text-green-600">
                              ✓ {doc.chunks} Chunks indiziert
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleDelete(doc.id)}
                      className="text-destructive hover:text-destructive hover:bg-destructive/10"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      ) : (
        <Card className="border border-dashed border-border">
          <CardContent className="py-12 text-center">
            <AlertCircle className="w-12 h-12 text-muted-foreground/50 mx-auto mb-4" />
            <p className="text-muted-foreground">
              Keine Dokumente hochgeladen. Laden Sie ein Dokument hoch, um zu beginnen.
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
