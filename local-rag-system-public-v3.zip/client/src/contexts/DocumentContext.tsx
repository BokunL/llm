import React, { createContext, useContext, useState, useEffect } from "react";

export interface Document {
  id: number;
  name: string;
  size: number;
  uploadedAt: Date;
  status: "processing" | "completed" | "error";
  chunks: number;
}

interface DocumentContextType {
  documents: Document[];
  addDocument: (doc: Document) => void;
  removeDocument: (id: number) => void;
  updateDocument: (id: number, updates: Partial<Document>) => void;
  setDocuments: (docs: Document[]) => void;
  isLoading: boolean;
  setIsLoading: (loading: boolean) => void;
}

const DocumentContext = createContext<DocumentContextType | undefined>(undefined);

export function DocumentProvider({ children }: { children: React.ReactNode }) {
  const [documents, setDocuments] = useState<Document[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  // Load documents from localStorage on mount
  useEffect(() => {
    const saved = localStorage.getItem("rag_documents");
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        setDocuments(
          parsed.map((doc: any) => ({
            ...doc,
            uploadedAt: new Date(doc.uploadedAt),
          }))
        );
      } catch (error) {
        console.error("Failed to load documents from localStorage:", error);
      }
    }
  }, []);

  // Save documents to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem("rag_documents", JSON.stringify(documents));
  }, [documents]);

  const addDocument = (doc: Document) => {
    setDocuments((prev) => [...prev, doc]);
  };

  const removeDocument = (id: number) => {
    setDocuments((prev) => prev.filter((doc) => doc.id !== id));
  };

  const updateDocument = (id: number, updates: Partial<Document>) => {
    setDocuments((prev) =>
      prev.map((doc) => (doc.id === id ? { ...doc, ...updates } : doc))
    );
  };

  const value: DocumentContextType = {
    documents,
    addDocument,
    removeDocument,
    updateDocument,
    setDocuments,
    isLoading,
    setIsLoading,
  };

  return (
    <DocumentContext.Provider value={value}>{children}</DocumentContext.Provider>
  );
}

export function useDocuments() {
  const context = useContext(DocumentContext);
  if (!context) {
    throw new Error("useDocuments must be used within DocumentProvider");
  }
  return context;
}
