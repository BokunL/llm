# Local RAG System - Konfigurationsvorlage

## Umgebungsvariablen für .env.local

Kopieren Sie diese Vorlage und passen Sie die Werte für Ihre Umgebung an.

### Für Docker Compose Deployment

```env
# ============================================
# Node Environment
# ============================================
NODE_ENV=production

# ============================================
# Database Configuration (Docker Compose)
# ============================================
DATABASE_URL=mysql://rag_user:rag_password_change_me@mysql:3306/local_rag_db

# ============================================
# S3 / MinIO Configuration (Docker Compose)
# ============================================
S3_ENDPOINT=http://minio:9000
S3_ACCESS_KEY=minioadmin
S3_SECRET_KEY=minioadmin_change_me
S3_BUCKET=rag-documents
S3_REGION=us-east-1

# ============================================
# Ollama LLM Configuration (Docker Compose)
# ============================================
OLLAMA_BASE_URL=http://ollama:11434
OLLAMA_MODEL=mistral

# ============================================
# JWT & Security
# ============================================
JWT_SECRET=your_jwt_secret_change_me_minimum_32_characters

# ============================================
# Application Configuration
# ============================================
VITE_APP_ID=local-rag-app
VITE_APP_TITLE=Local RAG System
```

### Für Manuelle Installation (Linux/macOS)

```env
# ============================================
# Node Environment
# ============================================
NODE_ENV=production

# ============================================
# Database Configuration (Lokal)
# ============================================
DATABASE_URL=mysql://rag_user:rag_password_change_me@localhost:3306/local_rag_db

# ============================================
# S3 / MinIO Configuration (Lokal)
# ============================================
S3_ENDPOINT=http://localhost:9000
S3_ACCESS_KEY=minioadmin
S3_SECRET_KEY=minioadmin_change_me
S3_BUCKET=rag-documents
S3_REGION=us-east-1

# ============================================
# Ollama LLM Configuration (Lokal)
# ============================================
OLLAMA_BASE_URL=http://localhost:11434
OLLAMA_MODEL=mistral

# ============================================
# JWT & Security
# ============================================
JWT_SECRET=your_jwt_secret_change_me_minimum_32_characters

# ============================================
# Application Configuration
# ============================================
VITE_APP_ID=local-rag-app
VITE_APP_TITLE=Local RAG System
```

## Konfigurationsparameter Erklärung

### Datenbank (DATABASE_URL)

**Format:** `mysql://username:password@host:port/database`

| Parameter | Beschreibung | Beispiel |
|-----------|-------------|---------|
| `username` | MySQL Benutzer | `rag_user` |
| `password` | MySQL Passwort | `rag_password_change_me` |
| `host` | MySQL Server Adresse | `localhost` oder `mysql` (Docker) |
| `port` | MySQL Port | `3306` |
| `database` | Datenbankname | `local_rag_db` |

**Wichtig:** Ändern Sie die Standard-Passwörter!

### S3 / MinIO Konfiguration

| Variable | Beschreibung | Beispiel |
|----------|-------------|---------|
| `S3_ENDPOINT` | MinIO/S3 API Endpoint | `http://localhost:9000` |
| `S3_ACCESS_KEY` | Access Key | `minioadmin` |
| `S3_SECRET_KEY` | Secret Key (ändern!) | `your_secret_key` |
| `S3_BUCKET` | Bucket Name | `rag-documents` |
| `S3_REGION` | AWS Region (optional) | `us-east-1` |

**Für AWS S3:**
```env
S3_ENDPOINT=https://s3.amazonaws.com
S3_ACCESS_KEY=your_aws_access_key
S3_SECRET_KEY=your_aws_secret_key
S3_BUCKET=your-bucket-name
S3_REGION=eu-central-1
```

### Ollama Konfiguration

| Variable | Beschreibung | Beispiel |
|----------|-------------|---------|
| `OLLAMA_BASE_URL` | Ollama API URL | `http://localhost:11434` |
| `OLLAMA_MODEL` | LLM Modellname | `mistral` |

**Verfügbare Modelle:**
- `mistral` - 7B, schnell, ~4 GB
- `llama2` - 7B, schnell, ~4 GB
- `neural-chat` - 7B, schnell, ~4 GB
- `dolphin-mixtral` - 8x7B, langsam, besser, ~27 GB

### JWT Secret

**Wichtig:** Generieren Sie einen sicheren, zufälligen String!

```bash
# Generiere einen sicheren JWT Secret
openssl rand -base64 32

# Oder mit Python
python3 -c "import secrets; print(secrets.token_urlsafe(32))"
```

**Mindestens 32 Zeichen erforderlich!**

## Sicherheits-Checkliste

Vor dem Produktiveinsatz:

- [ ] Alle Standard-Passwörter geändert
- [ ] JWT_SECRET mit `openssl rand -base64 32` generiert
- [ ] S3_SECRET_KEY geändert
- [ ] MySQL root Passwort geändert
- [ ] Firewall konfiguriert (nur lokale Verbindungen)
- [ ] HTTPS/SSL aktiviert (falls über Netzwerk zugänglich)
- [ ] Regelmäßige Backups eingerichtet
- [ ] Logs überwacht

## Passwort-Generierung

```bash
# Sichere Passwörter generieren
openssl rand -base64 32  # Für JWT_SECRET
openssl rand -base64 16  # Für andere Passwörter

# Oder mit Python
python3 << EOF
import secrets
print("JWT Secret:", secrets.token_urlsafe(32))
print("MySQL Password:", secrets.token_urlsafe(16))
print("S3 Secret:", secrets.token_urlsafe(16))
EOF
```

## Docker Compose Konfiguration

Zusätzlich zu den Umgebungsvariablen, passen Sie diese Werte in `docker-compose.yml` an:

```yaml
services:
  mysql:
    environment:
      MYSQL_ROOT_PASSWORD: your_root_password  # ÄNDERN!
      MYSQL_PASSWORD: rag_password_change_me   # ÄNDERN!

  minio:
    environment:
      MINIO_ROOT_PASSWORD: minioadmin_change_me  # ÄNDERN!

  app:
    environment:
      DATABASE_URL: mysql://rag_user:rag_password_change_me@mysql:3306/local_rag_db
      S3_SECRET_KEY: minioadmin_change_me  # ÄNDERN!
      JWT_SECRET: your_jwt_secret_change_me_minimum_32_characters  # ÄNDERN!
```

## Ollama Modelle Konfiguration

### Modell wechseln

```bash
# Modell herunterladen
docker exec -it local-rag-ollama ollama pull llama2

# In .env.local ändern
OLLAMA_MODEL=llama2

# Service neu starten
docker-compose restart app
```

### GPU-Beschleunigung aktivieren

In `docker-compose.yml`:

```yaml
ollama:
  deploy:
    resources:
      reservations:
        devices:
          - driver: nvidia
            count: 1
            capabilities: [gpu]
```

Voraussetzungen:
- NVIDIA GPU
- nvidia-docker installiert
- NVIDIA Container Runtime konfiguriert

## MinIO Bucket Erstellung

Nach dem Start von MinIO:

1. Öffne http://localhost:9001
2. Anmelden mit:
   - Username: `minioadmin`
   - Password: `minioadmin_change_me` (oder Ihr konfiguriertes Passwort)
3. Klicke auf "Buckets" → "Create Bucket"
4. Bucket-Name: `rag-documents`
5. Klicke "Create"

Oder mit MinIO Client:

```bash
# MinIO Client installieren
brew install minio/stable/mc  # macOS
# oder
apt-get install minio-mc      # Linux

# MinIO Alias hinzufügen
mc alias set minio http://localhost:9000 minioadmin minioadmin_change_me

# Bucket erstellen
mc mb minio/rag-documents
```

## Datenbank Initialisierung

Nach der Konfiguration:

```bash
# Docker Compose
docker-compose exec app pnpm db:push

# Manuell
cd /path/to/local-rag-system
pnpm db:push
```

Dies erstellt alle notwendigen Tabellen automatisch.

## Validierung der Konfiguration

Nach dem Start überprüfen Sie:

```bash
# Datenbank-Verbindung
mysql -u rag_user -p -h localhost -D local_rag_db -e "SELECT 1;"

# Ollama API
curl http://localhost:11434/api/tags

# MinIO API
curl http://localhost:9000/minio/health/live

# RAG App
curl http://localhost:3000
```

## Fehlerbehebung

### "Connection refused" bei Datenbank

```bash
# Überprüfe MySQL Status
docker-compose ps mysql
docker-compose logs mysql

# Oder manuell
sudo systemctl status mysql
mysql -u root -p -e "SELECT 1;"
```

### Ollama antwortet nicht

```bash
# Überprüfe Ollama
docker-compose ps ollama
docker-compose logs ollama

# Oder manuell
curl http://localhost:11434/api/tags
```

### S3 Upload schlägt fehl

```bash
# Überprüfe MinIO
docker-compose ps minio
docker-compose logs minio

# Überprüfe Bucket
mc ls minio/rag-documents
```

## Weitere Ressourcen

- [MySQL Dokumentation](https://dev.mysql.com/doc/)
- [Ollama Dokumentation](https://github.com/ollama/ollama)
- [MinIO Dokumentation](https://docs.min.io/)
- [Docker Compose Dokumentation](https://docs.docker.com/compose/)

---

**Version:** 1.0.0  
**Letzte Aktualisierung:** Februar 2026
