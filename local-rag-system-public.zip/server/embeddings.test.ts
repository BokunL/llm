import { describe, it, expect, vi, beforeEach } from "vitest";
import { cosineSimilarity, findSimilarChunks } from "./embeddings";

describe("Embeddings", () => {
  describe("cosineSimilarity", () => {
    it("should calculate cosine similarity correctly", () => {
      const a = [1, 0, 0];
      const b = [1, 0, 0];
      expect(cosineSimilarity(a, b)).toBe(1);
    });

    it("should return 0 for orthogonal vectors", () => {
      const a = [1, 0, 0];
      const b = [0, 1, 0];
      expect(cosineSimilarity(a, b)).toBe(0);
    });

    it("should handle negative similarity", () => {
      const a = [1, 0, 0];
      const b = [-1, 0, 0];
      expect(cosineSimilarity(a, b)).toBe(-1);
    });

    it("should throw error for vectors of different lengths", () => {
      const a = [1, 0];
      const b = [1, 0, 0];
      expect(() => cosineSimilarity(a, b)).toThrow();
    });
  });

  describe("findSimilarChunks", () => {
    const mockChunks = [
      {
        id: 1,
        embedding: [1, 0, 0],
        text: "First chunk about machine learning",
      },
      {
        id: 2,
        embedding: [0.9, 0.1, 0],
        text: "Second chunk about AI",
      },
      {
        id: 3,
        embedding: [0, 1, 0],
        text: "Third chunk about databases",
      },
      {
        id: 4,
        embedding: [0.1, 0.1, 0.1],
        text: "Fourth chunk with low similarity",
      },
    ];

    it("should return top K similar chunks", () => {
      const query = [1, 0, 0];
      const results = findSimilarChunks(query, mockChunks, 2);

      expect(results).toHaveLength(2);
      expect(results[0].id).toBe(1);
      expect(results[1].id).toBe(2);
    });

    it("should filter by similarity threshold", () => {
      const query = [0, 1, 0];
      const results = findSimilarChunks(query, mockChunks, 5);

      // Chunks with similarity > 0.3 threshold
      results.forEach((result) => {
        expect(result.similarity).toBeGreaterThan(0.3);
      });
    });

    it("should sort by similarity descending", () => {
      const query = [1, 0, 0];
      const results = findSimilarChunks(query, mockChunks, 5);

      for (let i = 0; i < results.length - 1; i++) {
        expect(results[i].similarity).toBeGreaterThanOrEqual(
          results[i + 1].similarity
        );
      }
    });

    it("should handle empty chunks array", () => {
      const query = [1, 0, 0];
      const results = findSimilarChunks(query, [], 5);

      expect(results).toHaveLength(0);
    });
  });
});
