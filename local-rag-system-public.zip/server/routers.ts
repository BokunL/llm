import { publicProcedure, router } from "./_core/trpc";
import { systemRouter } from "./_core/systemRouter";
import { z } from "zod";
import * as db from "./db";

export const appRouter = router({
  // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  
  auth: router({
    me: publicProcedure.query(() => null),
    logout: publicProcedure.mutation(() => {
      return {
        success: true,
      } as const;
    }),
  }),

  documents: router({
    list: publicProcedure.query(async () => {
      return db.getAllDocuments();
    }),

    delete: publicProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.deleteDocument(input.id);
        return { success: true };
      }),
  }),

  chat: router({
    createSession: publicProcedure
      .input(z.object({ title: z.string().optional() }))
      .mutation(async ({ input }) => {
        const result = await db.createChatSession({
          userId: 0,
          title: input.title || `Chat ${new Date().toLocaleDateString()}`,
        });
        return result;
      }),

    getSessions: publicProcedure.query(async () => {
      return db.getChatSessionsByUserId(0);
    }),

    getMessages: publicProcedure
      .input(z.object({ sessionId: z.number() }))
      .query(async ({ input }) => {
        const session = await db.getChatSessionById(input.sessionId);
        if (!session) {
          throw new Error("Session not found");
        }
        const messages = await db.getChatMessagesBySessionId(input.sessionId);
        return messages.map((msg) => ({
          ...msg,
          sources: JSON.parse(msg.sources || "[]"),
        }));
      }),

    deleteSession: publicProcedure
      .input(z.object({ sessionId: z.number() }))
      .mutation(async ({ input }) => {
        await db.deleteChatSession(input.sessionId);
        return { success: true };
      }),
  }),
});

export type AppRouter = typeof appRouter;
