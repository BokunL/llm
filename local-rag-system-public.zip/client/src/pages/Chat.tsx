import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Send, MessageSquare, AlertCircle, Copy, Check } from "lucide-react";
import { toast } from "sonner";
import { Streamdown } from "streamdown";
import { useDocuments } from "@/contexts/DocumentContext";

interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  sources?: Array<{ id: number; text: string; similarity: number }>;
  timestamp: Date;
}

export default function ChatPage() {
  const { documents } = useDocuments();
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages]);

  const handleSendMessage = async () => {
    if (!input.trim()) return;

    if (documents.length === 0) {
      toast.error("Bitte laden Sie zuerst ein Dokument hoch");
      return;
    }

    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content: input,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput("");
    setIsLoading(true);

    try {
      // TODO: Implement RAG query via tRPC
      await new Promise((resolve) => setTimeout(resolve, 2000));

      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: `Dies ist eine Demo-Antwort auf Ihre Frage: "${userMessage.content}"\n\nIn der vollständigen Implementierung würde das System:\n\n1. **Ihre Frage verstehen** - Die Frage wird in einen Vektor konvertiert\n2. **Relevante Dokumente finden** - Ähnliche Textpassagen werden aus Ihren Dokumenten abgerufen\n3. **Antwort generieren** - Ein lokales LLM generiert eine Antwort basierend auf den gefundenen Dokumenten\n4. **Quellen anzeigen** - Die verwendeten Textpassagen werden als Referenzen angezeigt`,
        sources: [
          {
            id: 1,
            text: "Beispiel-Textpassage aus dem hochgeladenen Dokument...",
            similarity: 0.85,
          },
        ],
        timestamp: new Date(),
      };

      setMessages((prev) => [...prev, assistantMessage]);
      toast.success("Antwort generiert");
    } catch (error) {
      toast.error("Fehler beim Generieren der Antwort");
    } finally {
      setIsLoading(false);
    }
  };

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Info Card */}
      {messages.length === 0 && (
        <Card className="bg-gradient-to-br from-blue-50 to-cyan-50 border-blue-200">
          <CardContent className="py-6">
            <div className="flex items-start gap-4">
              <MessageSquare className="w-5 h-5 text-blue-600 mt-1 flex-shrink-0" />
              <div>
                <h3 className="font-semibold text-blue-900 mb-1">Willkommen im Chat</h3>
                <p className="text-sm text-blue-800">
                  {documents.length === 0
                    ? "Laden Sie zunächst Dokumente hoch, dann können Sie Fragen dazu stellen."
                    : `Sie haben ${documents.length} Dokument${documents.length > 1 ? "e" : ""} hochgeladen. Stellen Sie Fragen dazu!`}
                  Das System findet relevante Textpassagen und beantwortet Ihre Fragen basierend auf dem Inhalt.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Chat Messages */}
      <Card className="flex flex-col h-[600px]">
        <CardHeader className="border-b border-border">
          <CardTitle>Chat mit Ihren Dokumenten</CardTitle>
          <CardDescription>
            {documents.length === 0
              ? "Keine Dokumente hochgeladen"
              : `${documents.length} Dokument${documents.length > 1 ? "e" : ""} verfügbar`}
          </CardDescription>
        </CardHeader>

        <ScrollArea className="flex-1">
          <div className="p-6 space-y-4">
            {messages.length === 0 ? (
              <div className="flex items-center justify-center h-full text-center text-muted-foreground">
                <div>
                  <MessageSquare className="w-12 h-12 mx-auto mb-4 opacity-20" />
                  <p>Keine Nachrichten. Stellen Sie eine Frage, um zu beginnen.</p>
                </div>
              </div>
            ) : (
              messages.map((message) => (
                <div
                  key={message.id}
                  className={`flex ${
                    message.role === "user" ? "justify-end" : "justify-start"
                  }`}
                >
                  <div
                    className={`max-w-md rounded-lg p-4 ${
                      message.role === "user"
                        ? "bg-accent text-accent-foreground"
                        : "bg-muted text-foreground border border-border"
                    }`}
                  >
                    {message.role === "assistant" ? (
                      <Streamdown>{message.content}</Streamdown>
                    ) : (
                      <p>{message.content}</p>
                    )}

                    {message.sources && message.sources.length > 0 && (
                      <div className="mt-4 pt-4 border-t border-border/30 space-y-2">
                        <p className="text-xs font-semibold opacity-70">Quellen:</p>
                        {message.sources.map((source) => (
                          <div
                            key={source.id}
                            className="text-xs p-2 rounded bg-white/10 opacity-80"
                          >
                            <div className="flex items-start justify-between gap-2">
                              <p className="line-clamp-2">{source.text}</p>
                              <button
                                onClick={() =>
                                  copyToClipboard(source.text, `source-${source.id}`)
                                }
                                className="flex-shrink-0 opacity-50 hover:opacity-100"
                              >
                                {copiedId === `source-${source.id}` ? (
                                  <Check className="w-3 h-3" />
                                ) : (
                                  <Copy className="w-3 h-3" />
                                )}
                              </button>
                            </div>
                            <p className="text-xs opacity-60 mt-1">
                              Ähnlichkeit: {(source.similarity * 100).toFixed(0)}%
                            </p>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              ))
            )}
            {isLoading && (
              <div className="flex justify-start">
                <div className="bg-muted text-foreground rounded-lg p-4 border border-border">
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full bg-accent animate-pulse" />
                    <span className="text-sm">Generiere Antwort...</span>
                  </div>
                </div>
              </div>
            )}
            <div ref={scrollRef} />
          </div>
        </ScrollArea>

        {/* Input Area */}
        <div className="border-t border-border p-4">
          <div className="flex gap-2">
            <Input
              placeholder="Stellen Sie eine Frage zu Ihren Dokumenten..."
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  handleSendMessage();
                }
              }}
              disabled={isLoading || documents.length === 0}
              className="flex-1"
            />
            <Button
              onClick={handleSendMessage}
              disabled={isLoading || !input.trim() || documents.length === 0}
              size="icon"
            >
              <Send className="w-4 h-4" />
            </Button>
          </div>
          <p className="text-xs text-muted-foreground mt-2">
            Drücken Sie Enter zum Senden
          </p>
        </div>
      </Card>
    </div>
  );
}
