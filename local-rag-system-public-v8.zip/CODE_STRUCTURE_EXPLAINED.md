# Code-Struktur erklärt (für Vibe Coder)

## 🎯 Die Grundidee

Stellen Sie sich das System wie ein Restaurant vor:

- **Client (Frontend)** = Die Speisekarte und der Tisch, wo Kunden sitzen
- **Server (Backend)** = Die Küche, wo das Essen zubereitet wird
- **Drizzle (Datenbank)** = Der Lagerbestand mit Zutaten
- **Shared** = Die Regeln und Konstanten, die beide kennen

Der **Client** fragt den **Server**, der **Server** spricht mit der **Datenbank**, und alle nutzen **Shared** für gemeinsame Regeln.

---

## 📂 Verzeichnisstruktur - Einfach erklärt

```
local-rag-system/
├── client/              ← Was der Benutzer sieht (React)
├── server/              ← Was hinter den Kulissen passiert (Express)
├── drizzle/             ← Die Datenbank-Struktur (MySQL)
├── shared/              ← Gemeinsame Regeln für beide
└── package.json         ← Die "Einkaufsliste" aller Abhängigkeiten
```

---

## 🔴 CLIENT (Frontend) - Was der Benutzer sieht

**Pfad:** `client/src/`

### Struktur:

```
client/src/
├── main.tsx              ← Der Startpunkt (wird zuerst geladen)
├── App.tsx               ← Die Hauptseite (Router)
├── pages/                ← Verschiedene Seiten
│   ├── Home.tsx          ← Startseite
│   ├── Chat.tsx          ← Chat-Seite
│   └── Documents.tsx     ← Dokumenten-Seite
├── components/           ← Wiederverwendbare UI-Teile
│   ├── DashboardLayout.tsx
│   ├── AIChatBox.tsx
│   └── ui/               ← Kleine Komponenten (Button, Input, etc.)
├── lib/
│   └── trpc.ts           ← Verbindung zum Server
└── index.css             ← Globale Styles
```

### Wie es funktioniert:

1. **main.tsx** wird zuerst ausgeführt
2. Es lädt **App.tsx**
3. **App.tsx** zeigt die richtige **Page** basierend auf der URL
4. Die **Page** nutzt **Components** für die UI
5. Die **Components** rufen den **Server** via **trpc** auf

### Beispiel-Fluss:

```
Benutzer öffnet http://localhost:3000/chat
    ↓
main.tsx startet
    ↓
App.tsx Router sieht "/chat"
    ↓
Chat.tsx Seite wird angezeigt
    ↓
Chat.tsx nutzt AIChatBox Component
    ↓
AIChatBox ruft Server auf: trpc.rag.query.useMutation()
    ↓
Server antwortet mit Ergebnis
    ↓
AIChatBox zeigt Antwort dem Benutzer
```

---

## 🔵 SERVER (Backend) - Was hinter den Kulissen passiert

**Pfad:** `server/`

### Struktur:

```
server/
├── _core/
│   ├── index.ts          ← Der Startpunkt (Express Server)
│   ├── context.ts        ← Wer ist der aktuelle Benutzer?
│   ├── trpc.ts           ← Wie funktioniert die Verbindung?
│   └── ...               ← Andere Hilfsfunktionen
├── routers.ts            ← Die API-Endpunkte (was der Client aufrufen kann)
├── db.ts                 ← Datenbankabfragen
├── embeddings.ts         ← Hugging Face Embeddings (Vektoren)
├── rag.ts                ← RAG-Logik (Fragen beantworten)
├── documentParser.ts     ← PDF/TXT/Markdown parsen
├── uploadHandler.ts      ← Dateien hochladen
└── storage.ts            ← Dateien speichern (S3)
```

### Wie es funktioniert:

1. **_core/index.ts** startet den Express Server auf Port 3000
2. Der Server wartet auf Anfragen vom **Client**
3. Der **Client** ruft **routers.ts** auf (z.B. `trpc.rag.query`)
4. **routers.ts** ruft andere Funktionen auf (z.B. `ragQuery` aus `rag.ts`)
5. Diese Funktionen arbeiten mit der **Datenbank** und **Dateien**
6. Das Ergebnis wird zurück zum **Client** gesendet

### Beispiel-Fluss:

```
Client: "Ich möchte eine Frage stellen"
    ↓
Client ruft: trpc.rag.query.useMutation()
    ↓
Server empfängt in routers.ts
    ↓
routers.ts ruft ragQuery() aus rag.ts auf
    ↓
ragQuery() ruft:
  - generateEmbedding() (embeddings.ts)
  - findSimilarChunks() (embeddings.ts)
  - callOllama() (rag.ts)
    ↓
ragQuery() gibt Antwort zurück
    ↓
Server sendet Antwort zum Client
    ↓
Client zeigt Antwort an
```

---

## 🟢 DRIZZLE (Datenbank) - Der Lagerbestand

**Pfad:** `drizzle/schema.ts`

### Was ist Drizzle?

Drizzle ist ein **ORM** (Object-Relational Mapping) - es übersetzt JavaScript in SQL.

### Struktur:

```
drizzle/
├── schema.ts             ← Tabellendefinitionen (was speichern wir?)
├── migrations/           ← SQL-Dateien (wie ändern wir die Struktur?)
└── meta/                 ← Metadaten (intern)
```

### Tabellen (vereinfacht):

```typescript
// users - Wer sind die Benutzer?
{
  id: 1,
  openId: "user123",
  name: "John",
  email: "john@example.com"
}

// documents - Welche Dateien wurden hochgeladen?
{
  id: 1,
  userId: 1,
  name: "my-document.pdf",
  fileKey: "s3://bucket/file.pdf"
}

// chunks - Wie ist das Dokument aufgeteilt?
{
  id: 1,
  documentId: 1,
  chunkText: "Dies ist ein Teil des Textes...",
  embedding: [0.1, 0.2, 0.3, ...] // 384 Zahlen
}

// chatHistory - Was wurde gefragt und geantwortet?
{
  id: 1,
  userId: 1,
  question: "Was ist RAG?",
  answer: "RAG ist...",
  sources: "[{id: 1, text: '...'}]"
}
```

### Wie wird es genutzt?

```typescript
// In server/db.ts:
const documents = await db.select().from(documents).where(...)
// Das wird zu SQL: SELECT * FROM documents WHERE ...
```

---

## 🟡 SHARED - Gemeinsame Regeln

**Pfad:** `shared/`

### Was ist darin?

```
shared/
├── const.ts              ← Konstanten (feste Werte)
│   └── COOKIE_NAME = "session"
├── types.ts              ← Typen (wie sieht ein Objekt aus?)
│   └── User, Document, Chunk
└── _core/
    └── errors.ts         ← Fehlertypen
```

### Warum brauchen wir das?

Damit **Client** und **Server** die gleiche Sprache sprechen.

```typescript
// shared/types.ts
export type User = {
  id: number;
  name: string;
  email: string;
}

// client/src/pages/Chat.tsx nutzt User
// server/routers.ts nutzt auch User
// Beide wissen genau, wie User aussieht!
```

---

## 🎬 Die Einstiegspunkte (Main Entry Points)

### 1. Frontend Einstiegspunkt

**Datei:** `client/src/main.tsx`

```typescript
// 1. React App wird geladen
import App from './App'

// 2. App wird in den HTML-Container eingefügt
ReactDOM.createRoot(document.getElementById('root')!).render(<App />)

// 3. App.tsx zeigt die richtige Seite
```

### 2. Backend Einstiegspunkt

**Datei:** `server/_core/index.ts`

```typescript
// 1. Express Server wird erstellt
const app = express()

// 2. tRPC Router wird verbunden
app.use('/api/trpc', ...)

// 3. Server startet auf Port 3000
app.listen(3000)
```

### 3. HTML Einstiegspunkt

**Datei:** `client/index.html`

```html
<!DOCTYPE html>
<html>
  <head>...</head>
  <body>
    <!-- Der Container, wo React eingefügt wird -->
    <div id="root"></div>
    
    <!-- main.tsx wird geladen -->
    <script type="module" src="/src/main.tsx"></script>
  </body>
</html>
```

---

## 🔗 Wie alles zusammenhängt - Visuell

```
┌─────────────────────────────────────────────────────────────┐
│                    BROWSER (Client)                         │
│                                                             │
│  client/index.html                                          │
│         ↓                                                   │
│  client/src/main.tsx (Startpunkt)                          │
│         ↓                                                   │
│  client/src/App.tsx (Router)                               │
│         ↓                                                   │
│  client/src/pages/Chat.tsx (Seite)                         │
│         ↓                                                   │
│  client/src/components/AIChatBox.tsx (UI)                  │
│         ↓                                                   │
│  client/src/lib/trpc.ts (Verbindung)                       │
│         ↓                                                   │
│  HTTP POST /api/trpc/rag.query                             │
│         ↓                                                   │
└─────────────────────────────────────────────────────────────┘
                         ↓ NETZWERK ↓
┌─────────────────────────────────────────────────────────────┐
│                    SERVER (Backend)                         │
│                                                             │
│  server/_core/index.ts (Startpunkt)                        │
│  - Express Server läuft auf Port 3000                      │
│  - tRPC Router ist verbunden                               │
│         ↓                                                   │
│  server/routers.ts (API-Endpunkte)                         │
│  - rag.query() Funktion                                    │
│         ↓                                                   │
│  server/rag.ts (Geschäftslogik)                            │
│  - ragQuery() Funktion                                     │
│  - Ruft embeddings.ts auf                                  │
│  - Ruft Ollama auf                                         │
│         ↓                                                   │
│  server/embeddings.ts (Hugging Face)                       │
│  - generateEmbedding()                                     │
│  - findSimilarChunks()                                     │
│         ↓                                                   │
│  server/db.ts (Datenbankabfragen)                          │
│  - getChunks()                                             │
│  - saveChat()                                              │
│         ↓                                                   │
└─────────────────────────────────────────────────────────────┘
                         ↓ SQL ↓
┌─────────────────────────────────────────────────────────────┐
│                    DATABASE (MySQL)                         │
│                                                             │
│  drizzle/schema.ts (Tabellenstruktur)                      │
│  - users                                                   │
│  - documents                                               │
│  - chunks                                                  │
│  - chatHistory                                             │
│         ↓                                                   │
│  Daten werden gespeichert/gelesen                          │
└─────────────────────────────────────────────────────────────┘
```

---

## 📝 Ein konkretes Beispiel: "Benutzer stellt eine Frage"

### Schritt 1: Benutzer tippt eine Frage ein

```
Client: "Was ist RAG?"
```

### Schritt 2: Frontend sendet Anfrage

**Datei:** `client/src/pages/Chat.tsx`

```typescript
const { mutate } = trpc.rag.query.useMutation()

mutate({
  question: "Was ist RAG?",
  documentIds: [1, 2, 3]
})
```

### Schritt 3: Server empfängt Anfrage

**Datei:** `server/routers.ts`

```typescript
rag: router({
  query: protectedProcedure
    .input(z.object({ question: z.string(), documentIds: z.array(z.number()) }))
    .mutation(async ({ input }) => {
      return await ragQuery(input.question, input.documentIds)
    })
})
```

### Schritt 4: RAG-Logik wird ausgeführt

**Datei:** `server/rag.ts`

```typescript
export async function ragQuery(question, documentIds) {
  // 1. Frage in Embedding umwandeln
  const queryEmbedding = await generateEmbedding(question)
  
  // 2. Ähnliche Chunks finden
  const similarChunks = findSimilarChunks(queryEmbedding, chunks)
  
  // 3. Kontext zusammenstellen
  const context = similarChunks.map(c => c.text).join("\n")
  
  // 4. Ollama aufrufen
  const answer = await callOllama(prompt)
  
  // 5. Antwort zurückgeben
  return { answer, sources: similarChunks }
}
```

### Schritt 5: Frontend zeigt Antwort

**Datei:** `client/src/pages/Chat.tsx`

```typescript
{/* Antwort wird angezeigt */}
<div>{data.answer}</div>

{/* Quellen werden angezeigt */}
{data.sources.map(source => (
  <div key={source.id}>{source.text}</div>
))}
```

---

## 🎓 Wichtige Konzepte

### tRPC (Type-safe RPC)

**Was ist das?**

Normalerweise:
```
Client: "Gib mir Daten"
Server: "OK, hier sind Daten"
Client: "Hmm, ist das ein String oder ein Number?"
```

Mit tRPC:
```
Client: "Gib mir Daten (ich weiß, es ist ein User mit id: number)"
Server: "OK, hier ist ein User mit id: number"
Client: "Perfekt, ich weiß genau, was ich bekomme"
```

**Datei:** `server/routers.ts`

```typescript
export const appRouter = router({
  rag: router({
    query: protectedProcedure
      .input(z.object({ question: z.string() }))
      .mutation(async ({ input }) => {
        // input.question ist garantiert ein String!
        return { answer: "..." }
      })
  })
})
```

### Drizzle ORM

**Was ist das?**

Normalerweise schreiben Sie SQL:
```sql
SELECT * FROM documents WHERE userId = 1
```

Mit Drizzle:
```typescript
const docs = await db
  .select()
  .from(documents)
  .where(eq(documents.userId, 1))
```

Es ist sicherer und einfacher!

---

## 🚀 Wie man Code hinzufügt

### Neue Seite hinzufügen

1. Erstelle `client/src/pages/MyPage.tsx`
2. Füge Route in `client/src/App.tsx` hinzu
3. Fertig!

### Neue API-Funktion hinzufügen

1. Erstelle Funktion in `server/routers.ts`
2. Rufe sie vom Client auf: `trpc.myFunction.useMutation()`
3. Fertig!

### Neue Datenbank-Tabelle hinzufügen

1. Füge Tabelle in `drizzle/schema.ts` hinzu
2. Führe `pnpm db:push` aus
3. Nutze sie in `server/db.ts`
4. Fertig!

---

## 📚 Zusammenfassung

| Teil | Rolle | Sprache | Wo? |
|------|-------|---------|-----|
| **Client** | Was der Benutzer sieht | React/TypeScript | `client/src/` |
| **Server** | Was hinter den Kulissen passiert | Express/TypeScript | `server/` |
| **Drizzle** | Wie Daten gespeichert werden | TypeScript → SQL | `drizzle/` |
| **Shared** | Gemeinsame Regeln | TypeScript | `shared/` |

**Der Fluss:**
```
Benutzer klickt → Client ruft Server auf → Server spricht mit Datenbank → Server antwortet → Client zeigt Ergebnis
```

---

**Viel Erfolg beim Vibe Coding!** 🎵

