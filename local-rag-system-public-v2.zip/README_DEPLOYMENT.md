# Local RAG System - Quick Start für IT-Team

## TL;DR - Schnellstart mit Docker Compose (5 Minuten)

```bash
# 1. Repository klonen/entpacken
cd /path/to/local-rag-system

# 2. Hugging Face API Key in .env.local setzen
echo "HUGGINGFACE_API_KEY=your_token_here" > .env.local
# Besuchen Sie https://huggingface.co/settings/tokens um einen Token zu erstellen

# 3. Docker Compose starten (alle Services werden automatisch konfiguriert)
docker-compose up -d

# 4. Ollama Modell herunterladen
docker exec -it local-rag-ollama ollama pull mistral

# 5. Anwendung öffnen
# http://localhost:3000
```

**Fertig!** Die Anwendung läuft auf http://localhost:3000

---

## Detaillierte Anleitung

### Voraussetzungen

- **Docker & Docker Compose** (empfohlen)
  ```bash
  # Installation auf Ubuntu/Debian
  sudo apt-get update
  sudo apt-get install -y docker.io docker-compose
  sudo usermod -aG docker $USER
  ```

- **Oder: Node.js 22+, MySQL 8.0+, Ollama**
  ```bash
  # Installation auf Ubuntu/Debian
  curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -
  sudo apt-get install -y nodejs mysql-server
  npm install -g pnpm
  curl -fsSL https://ollama.ai/install.sh | sh
  ```

### Schritt-für-Schritt Installation

#### Mit Docker Compose (Empfohlen)

```bash
# 1. Zum Projektverzeichnis navigieren
cd /path/to/local-rag-system

# 2. docker-compose.yml überprüfen (optional - Passwörter ändern!)
# Öffnen Sie docker-compose.yml und ändern Sie:
# - MYSQL_ROOT_PASSWORD
# - MYSQL_PASSWORD
# - MINIO_ROOT_PASSWORD

# 3. Services starten
docker-compose up -d

# 4. Warten Sie, bis alle Services laufen (ca. 30 Sekunden)
docker-compose ps

# 5. Ollama Modell herunterladen (ca. 4 GB)
docker exec -it local-rag-ollama ollama pull mistral

# 6. MinIO Bucket erstellen
# Öffnen Sie http://localhost:9001
# Anmelden: minioadmin / minioadmin_change_me
# Erstellen Sie einen Bucket: "rag-documents"

# 7. Anwendung öffnen
# http://localhost:3000
```

**Services Status überprüfen:**
```bash
docker-compose ps
docker-compose logs -f app
```

#### Manuelle Installation (Linux/macOS)

```bash
# 1. Abhängigkeiten installieren
sudo apt-get update
sudo apt-get install -y nodejs mysql-server
npm install -g pnpm
curl -fsSL https://ollama.ai/install.sh | sh

# 2. MySQL starten und konfigurieren
sudo systemctl start mysql
mysql -u root -p << EOF
CREATE DATABASE local_rag_db;
CREATE USER 'rag_user'@'localhost' IDENTIFIED BY 'rag_password_change_me';
GRANT ALL PRIVILEGES ON local_rag_db.* TO 'rag_user'@'localhost';
FLUSH PRIVILEGES;
EOF

# 3. Ollama starten
ollama serve &
sleep 5
ollama pull mistral

# 4. Projekt vorbereiten
cd /path/to/local-rag-system
pnpm install

# 5. Umgebungsvariablen setzen
cat > .env.local << EOF
NODE_ENV=production
DATABASE_URL=mysql://rag_user:rag_password_change_me@localhost:3306/local_rag_db
OLLAMA_BASE_URL=http://localhost:11434
JWT_SECRET=$(openssl rand -base64 32)
VITE_APP_ID=local-rag-app
EOF

# 6. Datenbank initialisieren
pnpm db:push

# 7. Anwendung bauen und starten
pnpm build
pnpm start

# Anwendung läuft auf http://localhost:3000
```

---

## Architektur-Übersicht

```
┌─────────────────────────────────────────────────────────┐
│                    Benutzer Browser                      │
│                   http://localhost:3000                  │
└────────────────────────┬────────────────────────────────┘
                         │
        ┌────────────────┼────────────────┐
        │                │                │
        ▼                ▼                ▼
   ┌─────────┐      ┌──────────┐    ┌──────────┐
   │ Frontend│      │ Backend  │    │ tRPC API │
   │ React   │      │ Express  │    │ Routes   │
   │ Port 80 │      │ Port 3000│    │          │
   └────┬────┘      └────┬─────┘    └────┬─────┘
        │                │               │
        └────────────────┼───────────────┘
                         │
        ┌────────────────┼────────────────┐
        │                │                │
        ▼                ▼                ▼
   ┌──────────┐    ┌──────────┐    ┌──────────┐
   │  MySQL   │    │  Ollama  │    │  MinIO   │
   │Database  │    │   LLM    │    │   S3     │
   │Port 3306 │    │Port 11434│    │Port 9000 │
   └──────────┘    └──────────┘    └──────────┘
```

---

## Konfiguration

### Wichtige Umgebungsvariablen

| Variable | Beschreibung | Beispiel |
|----------|-------------|---------|
| `DATABASE_URL` | MySQL Verbindungsstring | `mysql://user:pass@localhost:3306/db` |
| `OLLAMA_BASE_URL` | Ollama API URL | `http://localhost:11434` |
| `JWT_SECRET` | Session-Geheimnis (min. 32 Zeichen) | `$(openssl rand -base64 32)` |
| `S3_ENDPOINT` | MinIO/S3 Endpoint | `http://localhost:9000` |
| `S3_ACCESS_KEY` | S3 Access Key | `minioadmin` |
| `S3_SECRET_KEY` | S3 Secret Key | `your_secret_key` |

### Ollama Modelle

Verfügbare Modelle (nach Größe):

| Modell | Größe | VRAM | Download |
|--------|-------|------|----------|
| `mistral` | 7B | 4 GB | ~4 GB |
| `llama2` | 7B | 4 GB | ~4 GB |
| `neural-chat` | 7B | 4 GB | ~4 GB |
| `dolphin-mixtral` | 8x7B | 12 GB | ~27 GB |

```bash
# Modell wechseln
docker exec -it local-rag-ollama ollama pull llama2
# Dann in .env.local ändern: OLLAMA_MODEL=llama2
```

---

## Zugriff & Ports

| Service | URL | Benutzer | Passwort |
|---------|-----|----------|----------|
| RAG App | http://localhost:3000 | - | - |
| MinIO Console | http://localhost:9001 | minioadmin | minioadmin_change_me |
| MySQL | localhost:3306 | rag_user | rag_password_change_me |
| Ollama API | http://localhost:11434 | - | - |

---

## Häufige Probleme & Lösungen

### Problem: "Connection refused" bei Datenbank

**Lösung:**
```bash
# Docker: Überprüfe MySQL Container
docker-compose ps mysql
docker-compose logs mysql

# Manuell: Überprüfe MySQL Service
sudo systemctl status mysql
sudo systemctl restart mysql
```

### Problem: Ollama antwortet nicht

**Lösung:**
```bash
# Docker: Überprüfe Ollama Container
docker-compose ps ollama
docker exec -it local-rag-ollama ollama list

# Manuell: Starte Ollama neu
pkill ollama
ollama serve &
```

### Problem: "Port already in use"

**Lösung:**
```bash
# Finde Prozess auf Port 3000
lsof -i :3000

# Beende Prozess
kill -9 <PID>

# Oder ändere Port in docker-compose.yml
# ports:
#   - "8080:3000"  # Ändere 8080 zu einem freien Port
```

### Problem: Hohe RAM-Auslastung

**Lösung:**
- Verwenden Sie ein kleineres Ollama Modell: `ollama pull neural-chat`
- Erhöhen Sie die Systemressourcen
- Reduzieren Sie die Batch-Größe in der Konfiguration

### Problem: Langsame Antworten

**Lösung:**
```bash
# 1. Überprüfe Ollama Performance
curl http://localhost:11434/api/tags

# 2. Verwende GPU-Beschleunigung (falls verfügbar)
# Aktiviere NVIDIA GPU in docker-compose.yml

# 3. Optimiere Datenbank
docker-compose exec mysql mysql -u rag_user -p local_rag_db << EOF
OPTIMIZE TABLE documents;
OPTIMIZE TABLE documentChunks;
OPTIMIZE TABLE chatMessages;
EOF
```

---

## Monitoring & Logs

### Docker Compose

```bash
# Alle Logs anschauen
docker-compose logs -f

# Nur App-Logs
docker-compose logs -f app

# Nur MySQL-Logs
docker-compose logs -f mysql

# Nur Ollama-Logs
docker-compose logs -f ollama

# Services Status
docker-compose ps

# Ressourcennutzung
docker stats
```

### Manuell

```bash
# App-Logs (wenn mit systemd läuft)
journalctl -u local-rag-app -f

# MySQL Logs
sudo tail -f /var/log/mysql/error.log

# Ollama Logs
tail -f ~/.ollama/logs/ollama.log
```

---

## Backup & Wiederherstellung

### Datenbank Backup

```bash
# Docker
docker-compose exec mysql mysqldump -u rag_user -p local_rag_db > backup.sql

# Manuell
mysqldump -u rag_user -p local_rag_db > backup.sql
```

### Datenbank Wiederherstellung

```bash
# Docker
docker-compose exec mysql mysql -u rag_user -p local_rag_db < backup.sql

# Manuell
mysql -u rag_user -p local_rag_db < backup.sql
```

### S3 Daten Backup

```bash
# Mit MinIO Client
mc mirror minio/rag-documents ./backup/documents/

# Oder mit AWS CLI
aws s3 sync s3://rag-documents ./backup/documents/ \
  --endpoint-url http://localhost:9000 \
  --access-key minioadmin \
  --secret-key minioadmin_change_me
```

---

## Sicherheit

### Wichtige Sicherheitsmaßnahmen

1. **Passwörter ändern:**
   ```bash
   # Bearbeite docker-compose.yml oder .env.local
   # Ändere alle Standard-Passwörter!
   ```

2. **Firewall konfigurieren:**
   ```bash
   # Nur lokale Verbindungen erlauben
   sudo ufw default deny incoming
   sudo ufw allow from 127.0.0.1 to any port 3000
   sudo ufw allow from 127.0.0.1 to any port 3306
   sudo ufw allow from 127.0.0.1 to any port 11434
   sudo ufw enable
   ```

3. **HTTPS aktivieren:**
   ```bash
   # Verwende Reverse Proxy (nginx, Caddy)
   # oder Let's Encrypt für SSL-Zertifikate
   ```

4. **Regelmäßige Updates:**
   ```bash
   # Docker Images aktualisieren
   docker-compose pull
   docker-compose up -d --build
   ```

---

## Performance-Tipps

### Für schnellere Antworten

1. **Verwende GPU (falls verfügbar):**
   - Aktiviere NVIDIA GPU in docker-compose.yml
   - Installiere nvidia-docker

2. **Optimiere Datenbank:**
   ```bash
   # Erstelle Indizes
   docker-compose exec mysql mysql -u rag_user -p local_rag_db << EOF
   CREATE INDEX idx_documents_user ON documents(userId);
   CREATE INDEX idx_chunks_document ON documentChunks(documentId);
   CREATE INDEX idx_messages_session ON chatMessages(sessionId);
   EOF
   ```

3. **Erhöhe Systemressourcen:**
   - Mehr CPU-Kerne
   - Mehr RAM (mindestens 16 GB)
   - SSD statt HDD

---

## Wartung

### Tägliche Aufgaben
- Überprüfe Logs auf Fehler
- Überprüfe Speicherplatz

### Wöchentliche Aufgaben
- Backup der Datenbank
- Überprüfe Performance-Metriken

### Monatliche Aufgaben
- Datenbank-Optimierung
- Löschen alter Chat-Sessions
- Security-Updates

```bash
# Alte Chat-Sessions löschen (älter als 90 Tage)
docker-compose exec mysql mysql -u rag_user -p local_rag_db << EOF
DELETE FROM chatSessions WHERE updatedAt < DATE_SUB(NOW(), INTERVAL 90 DAY);
EOF
```

---

## Upgrade-Prozess

```bash
# 1. Backup erstellen
docker-compose exec mysql mysqldump -u rag_user -p local_rag_db > backup_$(date +%Y%m%d).sql

# 2. Code aktualisieren
cd /path/to/local-rag-system
git pull origin main

# 3. Services stoppen
docker-compose down

# 4. Services neu bauen und starten
docker-compose up -d --build

# 5. Migrationen durchführen (falls nötig)
docker-compose exec app pnpm db:push

# 6. Status überprüfen
docker-compose ps
docker-compose logs -f app
```

---

## Dateistruktur

```
local-rag-system/
├── client/                 # Frontend (React)
│   ├── src/
│   │   ├── pages/         # Seiten (Home, Chat, Documents)
│   │   ├── components/    # UI-Komponenten
│   │   └── lib/           # tRPC Client
│   └── index.html
├── server/                # Backend (Express + tRPC)
│   ├── routers.ts         # tRPC Routes
│   ├── db.ts              # Datenbank-Queries
│   ├── embeddings.ts      # Embedding-Logik
│   ├── rag.ts             # RAG-Pipeline
│   └── _core/             # Framework-Code
├── drizzle/               # Datenbankschema
│   └── schema.ts
├── docker-compose.yml     # Docker Compose Konfiguration
├── Dockerfile             # Docker Image Definition
├── package.json           # Node.js Dependencies
├── DEPLOYMENT_GUIDE.md    # Detaillierte Deployment-Anleitung
└── README_DEPLOYMENT.md   # Diese Datei
```

---

## Kontakt & Support

- **Dokumentation:** Siehe `DEPLOYMENT_GUIDE.md`
- **Quellcode:** Siehe `client/` und `server/` Verzeichnisse
- **API-Dokumentation:** Siehe `server/routers.ts`
- **Datenbankschema:** Siehe `drizzle/schema.ts`

---

**Version:** 1.0.0  
**Letzte Aktualisierung:** Februar 2026  
**Unterstützte Systeme:** Linux (Ubuntu 20.04+), macOS, Windows WSL2
