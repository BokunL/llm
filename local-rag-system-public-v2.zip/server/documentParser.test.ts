import { describe, it, expect } from "vitest";
import { chunkText, extractMetadata } from "./documentParser";

describe("Document Parser", () => {
  describe("chunkText", () => {
    it("should split text into chunks", () => {
      const text = "a".repeat(2500);
      const chunks = chunkText(text, 1000, 200);

      expect(chunks.length).toBeGreaterThan(1);
    });

    it("should create chunks with overlap", () => {
      const text = "The quick brown fox jumps over the lazy dog. ".repeat(50);
      const chunks = chunkText(text, 100, 20);

      expect(chunks.length).toBeGreaterThan(0);
      // Check that chunks have reasonable size
      chunks.forEach((chunk) => {
        expect(chunk.length).toBeGreaterThan(0);
      });
    });

    it("should handle short text", () => {
      const text = "Short text";
      const chunks = chunkText(text, 100, 20);

      expect(chunks.length).toBeGreaterThanOrEqual(1);
      expect(chunks[0]).toBe(text);
    });

    it("should filter empty chunks", () => {
      const text = "   \n\n   Text   \n\n   ";
      const chunks = chunkText(text, 100, 20);

      chunks.forEach((chunk) => {
        expect(chunk.length).toBeGreaterThan(0);
      });
    });

    it("should handle custom chunk size and overlap", () => {
      const text = "a".repeat(500);
      const chunks = chunkText(text, 100, 50);

      expect(chunks.length).toBeGreaterThan(0);
      chunks.forEach((chunk) => {
        expect(chunk.length).toBeLessThanOrEqual(100);
      });
    });
  });

  describe("extractMetadata", () => {
    it("should extract correct metadata", () => {
      const text = "Hello world";
      const metadata = extractMetadata(text, 0);

      expect(metadata.chunkIndex).toBe(0);
      expect(metadata.charCount).toBe(11);
      expect(metadata.wordCount).toBe(2);
    });

    it("should count words correctly", () => {
      const text = "The quick brown fox jumps over the lazy dog";
      const metadata = extractMetadata(text, 1);

      expect(metadata.wordCount).toBe(9);
      expect(metadata.chunkIndex).toBe(1);
    });

    it("should handle empty text", () => {
      const text = "";
      const metadata = extractMetadata(text, 0);

      expect(metadata.charCount).toBe(0);
      expect(metadata.wordCount).toBe(0);
    });

    it("should handle text with multiple spaces", () => {
      const text = "Word1   word2    word3";
      const metadata = extractMetadata(text, 0);

      expect(metadata.wordCount).toBe(3);
    });
  });
});
