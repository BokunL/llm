import { HuggingFaceInferenceEmbeddings } from "@langchain/community/embeddings/hf";
import { RecursiveCharacterTextSplitter } from "@langchain/textsplitters";

const EMBEDDING_MODEL = "sentence-transformers/all-MiniLM-L6-v2";
const EMBEDDING_DIMENSION = 384;

let embeddingsInstance: HuggingFaceInferenceEmbeddings | null = null;

/**
 * Initialize Hugging Face Embeddings
 * Uses sentence-transformers/all-MiniLM-L6-v2 model (384 dimensions)
 */
export function initializeEmbeddings(): HuggingFaceInferenceEmbeddings {
  if (embeddingsInstance) {
    return embeddingsInstance;
  }

  const apiKey = process.env.HUGGINGFACE_API_KEY;
  if (!apiKey) {
    throw new Error("HUGGINGFACE_API_KEY environment variable is required");
  }

  embeddingsInstance = new HuggingFaceInferenceEmbeddings({
    apiKey,
    model: EMBEDDING_MODEL,
  });

  return embeddingsInstance;
}

/**
 * Generate embedding for a single text
 */
export async function generateEmbedding(text: string): Promise<number[]> {
  const embeddings = initializeEmbeddings();
  return embeddings.embedQuery(text);
}

/**
 * Generate embeddings for multiple texts
 */
export async function generateEmbeddings(texts: string[]): Promise<number[][]> {
  const embeddings = initializeEmbeddings();
  return embeddings.embedDocuments(texts);
}

/**
 * Calculate cosine similarity between two vectors
 */
export function cosineSimilarity(a: number[], b: number[]): number {
  if (a.length !== b.length) {
    throw new Error("Vectors must have the same length");
  }

  let dotProduct = 0;
  let normA = 0;
  let normB = 0;

  for (let i = 0; i < a.length; i++) {
    dotProduct += a[i] * b[i];
    normA += a[i] * a[i];
    normB += b[i] * b[i];
  }

  normA = Math.sqrt(normA);
  normB = Math.sqrt(normB);

  if (normA === 0 || normB === 0) {
    return 0;
  }

  return dotProduct / (normA * normB);
}

/**
 * Find similar chunks based on embedding similarity
 */
export function findSimilarChunks(
  queryEmbedding: number[],
  chunks: Array<{
    id: number;
    embedding: number[];
    text: string;
  }>,
  topK: number = 5,
  threshold: number = 0.3
): Array<{
  id: number;
  text: string;
  similarity: number;
}> {
  const results = chunks
    .map((chunk) => ({
      id: chunk.id,
      text: chunk.text,
      similarity: cosineSimilarity(queryEmbedding, chunk.embedding),
    }))
    .filter((result) => result.similarity > threshold)
    .sort((a, b) => b.similarity - a.similarity)
    .slice(0, topK);

  return results;
}

/**
 * Split text into chunks using LangChain's RecursiveCharacterTextSplitter
 */
export async function splitTextIntoChunks(
  text: string,
  chunkSize: number = 1000,
  chunkOverlap: number = 200
): Promise<string[]> {
  const splitter = new RecursiveCharacterTextSplitter({
    chunkSize,
    chunkOverlap,
  });

  const chunks = await splitter.splitText(text);
  return chunks.filter((chunk) => chunk.trim().length > 0);
}

/**
 * Extract metadata from a chunk
 */
export function extractMetadata(
  text: string,
  chunkIndex: number
): {
  chunkIndex: number;
  charCount: number;
  wordCount: number;
} {
  const charCount = text.length;
  const wordCount = text.trim().split(/\s+/).length;

  return {
    chunkIndex,
    charCount,
    wordCount,
  };
}
