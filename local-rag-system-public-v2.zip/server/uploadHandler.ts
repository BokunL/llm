/**
 * Document upload and processing handler
 */

import { storagePut } from "./storage";
import { parseDocument, chunkText, extractMetadata } from "./documentParser";
import { generateEmbedding } from "./embeddings";
import * as db from "./db";
import { nanoid } from "nanoid";

export interface UploadResult {
  documentId: number;
  fileName: string;
  fileSize: number;
  totalChunks: number;
  processingStatus: string;
}

/**
 * Process uploaded file and create embeddings
 */
export async function processUploadedFile(
  buffer: Buffer,
  fileName: string,
  mimeType: string,
  userId: number
): Promise<UploadResult> {
  try {
    // Generate unique file key
    const fileKey = `documents/${userId}/${nanoid(8)}-${fileName}`;

    // Upload to S3
    const { url: fileUrl } = await storagePut(fileKey, buffer, mimeType);

    // Create document record
    const docResult = await db.createDocument({
      userId,
      name: fileName,
      fileKey,
      fileUrl,
      mimeType,
      fileSize: buffer.length,
      processingStatus: "processing",
    });

    // Get the document ID from the insert result
    const documentId = (docResult as any).insertId || (docResult as any)[0]?.id;

    // Parse document
    const parsed = await parseDocument(buffer, mimeType);

    // Chunk text
    const chunks = chunkText(parsed.text);

    // Generate embeddings for each chunk
    let successCount = 0;
    for (let i = 0; i < chunks.length; i++) {
      try {
        const chunkText = chunks[i];
        const embedding = await generateEmbedding(chunkText);
        const metadata = extractMetadata(chunkText, i);

        await db.createDocumentChunk({
          documentId,
          chunkIndex: i,
          chunkText,
          embedding: JSON.stringify(embedding),
          metadata: JSON.stringify(metadata),
        });

        successCount++;
      } catch (error) {
        console.error(`Failed to process chunk ${i}:`, error);
      }
    }

    // Update document status
    await db.updateDocumentStatus(documentId, "completed");

    return {
      documentId,
      fileName,
      fileSize: buffer.length,
      totalChunks: successCount,
      processingStatus: "completed",
    };
  } catch (error) {
    console.error("Error processing uploaded file:", error);
    throw error;
  }
}

/**
 * Validate file before upload
 */
export function validateFile(
  fileName: string,
  mimeType: string,
  fileSize: number
): { valid: boolean; error?: string } {
  const MAX_FILE_SIZE = 50 * 1024 * 1024; // 50MB
  const ALLOWED_TYPES = [
    "application/pdf",
    "text/plain",
    "text/markdown",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  ];

  if (fileSize > MAX_FILE_SIZE) {
    return { valid: false, error: "File size exceeds 50MB limit" };
  }

  if (!ALLOWED_TYPES.includes(mimeType)) {
    return { valid: false, error: "File type not supported" };
  }

  const validExtensions = [".pdf", ".txt", ".md", ".docx"];
  const hasValidExtension = validExtensions.some((ext) =>
    fileName.toLowerCase().endsWith(ext)
  );

  if (!hasValidExtension) {
    return { valid: false, error: "File extension not supported" };
  }

  return { valid: true };
}
