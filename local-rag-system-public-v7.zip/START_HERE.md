# 🚀 Local RAG System - START HERE

Willkommen! Dieses Dokument führt Sie durch die ersten Schritte zum Starten des Local RAG Systems.

## 📋 Was ist in diesem Archiv enthalten?

```
local-rag-system/
├── README_DEPLOYMENT.md          ← LESEN SIE ZUERST (5-Minuten Quick-Start)
├── DEPLOYMENT_GUIDE.md           ← Detaillierte Anleitung für IT-Teams
├── CONFIGURATION_TEMPLATE.md     ← Konfigurationsvorlage
├── docker-compose.yml            ← Docker Compose Konfiguration
├── Dockerfile                    ← Container Image Definition
├── package.json                  ← Node.js Abhängigkeiten
├── client/                       ← React Frontend
│   ├── src/
│   │   ├── pages/               ← Chat, Documents, Home Seiten
│   │   ├── components/          ← UI Komponenten
│   │   └── lib/                 ← tRPC Client
│   └── index.html
├── server/                       ← Express + tRPC Backend
│   ├── routers.ts               ← API Routen
│   ├── db.ts                    ← Datenbank Queries
│   ├── embeddings.ts            ← Embedding Logik
│   ├── rag.ts                   ← RAG Pipeline
│   ├── documentParser.ts        ← PDF/TXT/Markdown Parser
│   └── uploadHandler.ts         ← File Upload Handler
├── drizzle/                      ← Datenbankschema
│   └── schema.ts
└── todo.md                       ← Projekt Fortschritt
```

## ⚡ Schnellstart (5 Minuten)

### Voraussetzung
- Docker und Docker Compose installiert
- Mindestens 16 GB RAM verfügbar
- 50 GB freier Speicherplatz

### Schritt 1: Projekt entpacken
```bash
unzip local-rag-system-complete.zip
cd local-rag-system
```

### Schritt 2: Docker Compose starten
```bash
docker-compose up -d
```

### Schritt 3: Ollama Modell herunterladen
```bash
docker exec -it local-rag-ollama ollama pull mistral
```

### Schritt 4: MinIO Bucket erstellen
```bash
# Öffne http://localhost:9001 im Browser
# Anmelden: minioadmin / minioadmin_change_me
# Erstelle einen Bucket: "rag-documents"
```

### Schritt 5: Anwendung öffnen
```
http://localhost:3000
```

**Fertig!** 🎉

---

## 📚 Dokumentation

| Datei | Zweck |
|-------|-------|
| **README_DEPLOYMENT.md** | Quick-Start und häufige Probleme (START HERE!) |
| **DEPLOYMENT_GUIDE.md** | Vollständige Deployment-Anleitung (50+ Seiten) |
| **CONFIGURATION_TEMPLATE.md** | Umgebungsvariablen Erklärung |

## 🔧 Systemanforderungen

### Minimum
- CPU: 6-8 Kerne
- RAM: 16 GB
- Speicher: 50 GB SSD

### Empfohlen
- CPU: 8+ Kerne
- RAM: 32 GB
- Speicher: 100+ GB SSD
- GPU: NVIDIA (optional, für schnellere Inferenz)

## 🏗️ Architektur

```
Browser (http://localhost:3000)
    ↓
React Frontend (Port 3000)
    ↓
Express + tRPC Backend (Port 3000)
    ↓
┌─────────────┬──────────────┬──────────────┐
│   MySQL     │    Ollama    │    MinIO     │
│ (Port 3306) │ (Port 11434) │ (Port 9000)  │
└─────────────┴──────────────┴──────────────┘
```

## 🔑 Standard Zugangsdaten

| Service | URL | Benutzer | Passwort |
|---------|-----|----------|----------|
| RAG App | http://localhost:3000 | - | - |
| MinIO Console | http://localhost:9001 | minioadmin | minioadmin_change_me |
| MySQL | localhost:3306 | rag_user | rag_password_change_me |
| Ollama API | http://localhost:11434 | - | - |

**⚠️ WICHTIG:** Ändern Sie diese Passwörter vor dem Produktiveinsatz!

## 🐛 Häufige Probleme

### Problem: "Port already in use"
```bash
# Finde den Prozess
lsof -i :3000

# Beende ihn
kill -9 <PID>
```

### Problem: Datenbank-Verbindungsfehler
```bash
# Überprüfe MySQL
docker-compose ps mysql
docker-compose logs mysql
```

### Problem: Ollama antwortet nicht
```bash
# Überprüfe Ollama
curl http://localhost:11434/api/tags
```

Weitere Probleme siehe **README_DEPLOYMENT.md**

## 📖 Nächste Schritte

1. **Lesen Sie README_DEPLOYMENT.md** für detaillierte Anweisungen
2. **Konfigurieren Sie Passwörter** in docker-compose.yml
3. **Testen Sie die Anwendung** unter http://localhost:3000
4. **Lesen Sie DEPLOYMENT_GUIDE.md** für Produktiveinsatz

## 🔒 Sicherheit

Vor dem Produktiveinsatz:

- [ ] Alle Standard-Passwörter ändern
- [ ] JWT_SECRET mit `openssl rand -base64 32` generieren
- [ ] Firewall konfigurieren
- [ ] HTTPS/SSL aktivieren
- [ ] Regelmäßige Backups einrichten

## 📞 Support

- **Dokumentation:** Siehe README_DEPLOYMENT.md und DEPLOYMENT_GUIDE.md
- **Quellcode:** Siehe client/ und server/ Verzeichnisse
- **Datenbank:** Siehe drizzle/schema.ts

## 🎯 Features

✅ Dokumenten-Upload (PDF, TXT, Markdown)
✅ Automatische Dokumenten-Indizierung
✅ Intelligente Frage-Antwort-Funktion
✅ Dokumentenverwaltung
✅ Chat-Interface mit Verlauf
✅ REST-API Endpunkte
✅ Quellen-Referenzierung
✅ Echtzeit-Verarbeitungsstatus

## 📊 Datenbankschema

Das System erstellt automatisch folgende Tabellen:

- **users** - Benutzer und Authentifizierung
- **documents** - Hochgeladene Dokumente
- **documentChunks** - Dokumenten-Chunks mit Embeddings
- **chatSessions** - Chat-Sitzungen
- **chatMessages** - Chat-Nachrichten mit Quellen

## 🚀 Deployment-Optionen

### Option 1: Docker Compose (Empfohlen)
```bash
docker-compose up -d
```

### Option 2: Manuelle Installation
Siehe DEPLOYMENT_GUIDE.md für Linux/macOS Installation

### Option 3: Kubernetes
Siehe DEPLOYMENT_GUIDE.md für Kubernetes Deployment

## 📝 Lizenz

Dieses Projekt ist für interne Verwendung bestimmt.

---

**Version:** 1.0.0
**Letzte Aktualisierung:** Februar 2026

**Haben Sie Fragen?** Lesen Sie README_DEPLOYMENT.md oder DEPLOYMENT_GUIDE.md
