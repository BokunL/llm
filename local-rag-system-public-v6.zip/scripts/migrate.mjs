#!/usr/bin/env node

/**
 * Database Migration Script
 * Runs Drizzle migrations on startup
 * This ensures all tables are created before the app starts
 */

import { spawn } from 'child_process';
import { existsSync } from 'fs';
import { resolve } from 'path';

const isDev = process.env.NODE_ENV === 'development';
const drizzleDir = resolve(process.cwd(), 'drizzle');

console.log('[Migration] Starting database migrations...');
console.log('[Migration] Environment:', process.env.NODE_ENV || 'production');
console.log('[Migration] Drizzle directory:', drizzleDir);

// Check if drizzle directory exists
if (!existsSync(drizzleDir)) {
  console.error('[Migration] ERROR: drizzle directory not found');
  process.exit(1);
}

// Run migrations
const migrate = spawn('pnpm', ['exec', 'drizzle-kit', 'migrate'], {
  stdio: 'inherit',
  cwd: process.cwd(),
});

migrate.on('close', (code) => {
  if (code === 0) {
    console.log('[Migration] ✅ Database migrations completed successfully');
    process.exit(0);
  } else {
    console.error(`[Migration] ❌ Migration failed with code ${code}`);
    process.exit(1);
  }
});

migrate.on('error', (err) => {
  console.error('[Migration] ERROR:', err);
  process.exit(1);
});
