# Local RAG System - TODO

## Migration zu LangChain + Hugging Face
- [x] LangChain und Hugging Face Dependencies installieren
- [x] Embedding-Logik mit HuggingFaceEmbeddings migrieren
- [x] RAG-Pipeline mit LangChain migrieren
- [x] Tests aktualisieren
- [x] Dokumentation aktualisieren
- [ ] ZIP-Archiv erstellen

## Datenbankschema & API-Struktur
- [x] Datenbankschema für Dokumente definieren (name, size, uploadDate, userId, fileKey)
- [x] Datenbankschema für Chat-Verlauf definieren (question, answer, sources, userId, timestamp)
- [x] Datenbankschema für Embeddings/Chunks definieren (docId, chunkText, embedding, metadata)
- [x] tRPC-Routen für Dokumentenverwaltung erstellen
- [x] tRPC-Routen für Chat-Funktionalität erstellen

## Dokumenten-Upload & Verarbeitung
- [x] File-Upload-Komponente im Frontend entwickeln
- [x] Backend-Upload-Handler mit S3-Integration implementieren
- [x] Datei-Parser für PDF, TXT, Markdown entwickeln
- [x] Dokumenten-Chunking-Logik implementieren
- [x] Embedding-Generierung mit Ollama/Hugging Face integrieren
- [ ] Vektordatenbank-Integration (FAISS oder ähnlich)

## RAG-Logik & Suche
- [x] Embedding-Ähnlichkeitssuche implementieren
- [x] Kontext-Retrieval-Funktion entwickeln
- [x] Ollama LLM-Integration für Antwort-Generierung
- [x] Quellen-Referenzierung mit Chunk-Metadaten

## Frontend UI
- [x] Elegantes Design-System mit Tailwind definieren
- [x] Dokumenten-Upload-Interface gestalten
- [x] Dokumentenverwaltungs-Seite mit Tabelle entwickeln
- [x] Chat-Interface mit Nachrichtenverlauf erstellen
- [x] Markdown-Rendering für Antworten implementieren
- [x] Quellen-Anzeige-Komponente entwickeln
- [x] Echtzeit-Verarbeitungsstatus-Anzeige

## Chat & Echtzeit-Verarbeitung
- [ ] Chat-Eingabe-Komponente mit Auto-Focus
- [ ] Nachrichtenverlauf-Anzeige mit Scrolling
- [ ] Loading-Indikatoren für Antwort-Generierung
- [ ] Error-Handling und Benutzer-Feedback
- [ ] Quellen-Referenzen in Chat-Nachrichten anzeigen

## Tests & Dokumentation
- [ ] Unit-Tests für Embedding-Logik schreiben
- [ ] Integration-Tests für Upload-Flow schreiben
- [ ] API-Dokumentation erstellen
- [ ] README mit Setup-Anleitung aktualisieren

## Deployment & Finalisierung
- [ ] Checkpoint erstellen
- [ ] Projekt dem Benutzer präsentieren
