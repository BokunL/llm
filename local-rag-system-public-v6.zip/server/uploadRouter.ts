import { publicProcedure, router } from "./_core/trpc";
import { z } from "zod";
import * as db from "./db";
import { parseDocument } from "./documentParser";
import { generateEmbedding, splitTextIntoChunks } from "./embeddings";

export const uploadRouter = router({
  upload: publicProcedure
    .input(z.object({
      fileName: z.string(),
      fileContent: z.string(), // Base64 encoded
      fileType: z.enum(["pdf", "txt", "md", "docx"]),
    }))
    .mutation(async ({ input }) => {
      try {
        console.log(`[Upload] Processing file: ${input.fileName}`);

        // Decode base64 content
        const buffer = Buffer.from(input.fileContent, "base64");

        // Parse document based on type
        let parsedDoc;
        try {
          parsedDoc = await parseDocument(buffer, input.fileType);
        } catch (parseError) {
          console.error("[Upload] Parse error:", parseError);
          throw new Error(`Failed to parse ${input.fileType} file`);
        }

        const text = parsedDoc.text;
        if (!text || text.trim().length === 0) {
          throw new Error("Document is empty or could not be parsed");
        }

        console.log(`[Upload] Parsed ${text.length} characters from ${input.fileName}`);

        // Create document in database
        const result = await db.createDocument({
          name: input.fileName,
          fileKey: `documents/${Date.now()}-${input.fileName}`,
          fileUrl: `s3://rag-documents/${Date.now()}-${input.fileName}`,
          mimeType: getMimeType(input.fileType),
          fileSize: buffer.length,
          userId: 0, // Public user
          totalChunks: 0, // Will be updated after chunks are created
          processingStatus: "processing",
        });

        // Get the inserted document ID
        // Drizzle returns the insert result, we need to get the ID from the result
        const documents = await db.getAllDocuments();
        const doc = documents[documents.length - 1]; // Get the last inserted document
        
        if (!doc || !doc.id) {
          throw new Error("Failed to create document in database");
        }

        const documentId = doc.id;
        console.log(`[Upload] Created document with ID: ${documentId}`);

        // Split text into chunks
        const chunks = await splitTextIntoChunks(text);
        console.log(`[Upload] Split into ${chunks.length} chunks`);

        // Generate embeddings and save chunks
        let successCount = 0;
        for (let i = 0; i < chunks.length; i++) {
          try {
            const chunk = chunks[i];
            
            // Generate embedding
            const embedding = await generateEmbedding(chunk);
            
            // Save chunk to database
            await db.createDocumentChunk({
              documentId,
              chunkIndex: i,
              chunkText: chunk,
              embedding: JSON.stringify(embedding),
              metadata: JSON.stringify({
                chunkIndex: i,
                totalChunks: chunks.length,
                documentName: input.fileName,
              }),
            });
            
            successCount++;
            
            // Log progress every 10 chunks
            if ((i + 1) % 10 === 0) {
              console.log(`[Upload] Processed ${i + 1}/${chunks.length} chunks`);
            }
          } catch (chunkError) {
            console.error(`[Upload] Error processing chunk ${i}:`, chunkError);
            // Continue with next chunk instead of failing
          }
        }

        console.log(`[Upload] Successfully saved ${successCount}/${chunks.length} chunks`);

        // Update document status
        await db.updateDocumentStatus(documentId, "completed");

        if (successCount === 0) {
          throw new Error("Failed to save any chunks to database");
        }

        return {
          success: true,
          documentId,
          fileName: input.fileName,
          chunksCreated: successCount,
          message: `Successfully uploaded ${input.fileName} with ${successCount} chunks`,
        };
      } catch (error) {
        console.error("[Upload] Error:", error);
        throw error;
      }
    }),
});

function getMimeType(fileType: string): string {
  const mimeTypes: Record<string, string> = {
    pdf: "application/pdf",
    txt: "text/plain",
    md: "text/markdown",
    docx: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  };
  return mimeTypes[fileType] || "application/octet-stream";
}
