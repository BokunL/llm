/**
 * RAG (Retrieval-Augmented Generation) logic using LangChain + Ollama
 * Handles document retrieval and LLM-based answer generation
 */

import { findSimilarChunks, generateEmbedding } from "./embeddings";

const OLLAMA_BASE_URL = process.env.OLLAMA_BASE_URL || "http://localhost:11434";
const OLLAMA_MODEL = process.env.OLLAMA_MODEL || "mistral";

export interface RAGResponse {
  answer: string;
  sources: Array<{
    id: number;
    text: string;
    documentName: string;
    similarity: number;
  }>;
}

/**
 * Call Ollama LLM with a prompt
 */
async function callOllama(prompt: string): Promise<string> {
  try {
    const response = await fetch(`${OLLAMA_BASE_URL}/api/generate`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: OLLAMA_MODEL,
        prompt,
        stream: false,
        temperature: 0.7,
      }),
    });

    if (!response.ok) {
      throw new Error(`Ollama API error: ${response.statusText}`);
    }

    const data = (await response.json()) as { response: string };
    return data.response || "";
  } catch (error) {
    console.error("Error calling Ollama:", error);
    throw error;
  }
}

/**
 * RAG Query - Retrieval Augmented Generation
 * 1. Generate embedding for the query
 * 2. Find similar chunks from the database
 * 3. Create a context from the chunks
 * 4. Generate an answer using the LLM with the context
 */
export async function ragQuery(
  question: string,
  chunks: Array<{
    id: number;
    embedding: number[];
    text: string;
    documentId: number;
    documentName: string;
  }>,
  maxChunks: number = 5
): Promise<RAGResponse> {
  try {
    // Step 1: Generate embedding for the query
    const queryEmbedding = await generateEmbedding(question);

    // Step 2: Find similar chunks
    const similarChunks = findSimilarChunks(
      queryEmbedding,
      chunks,
      maxChunks,
      0.3
    );

    if (similarChunks.length === 0) {
      return {
        answer:
          "Ich konnte keine relevanten Informationen in den hochgeladenen Dokumenten finden, um Ihre Frage zu beantworten.",
        sources: [],
      };
    }

    // Step 3: Create context from chunks
    const context = similarChunks
      .map((chunk, idx) => `[Quelle ${idx + 1}]: ${chunk.text}`)
      .join("\n\n");

    // Step 4: Create RAG prompt
    const ragPrompt = `Sie sind ein hilfreicher Assistent, der Fragen basierend auf bereitgestellten Dokumenten beantwortet.

Verwenden Sie die folgenden Dokumenten-Auszüge, um die Frage zu beantworten:

${context}

Frage: ${question}

Antwort: Beantworten Sie die Frage basierend auf den bereitgestellten Dokumenten. Wenn die Antwort nicht in den Dokumenten enthalten ist, sagen Sie, dass Sie die Antwort nicht finden können.`;

    // Step 5: Generate answer using Ollama
    const answer = await callOllama(ragPrompt);

    // Step 6: Return answer with sources
    return {
      answer,
      sources: similarChunks.map((chunk) => {
        const sourceChunk = chunks.find((c) => c.id === chunk.id);
        return {
          id: chunk.id,
          text: chunk.text.substring(0, 200) + "...",
          documentName: sourceChunk?.documentName || "Unknown",
          similarity: chunk.similarity,
        };
      }),
    };
  } catch (error) {
    console.error("Error in RAG query:", error);
    throw error;
  }
}

/**
 * Simple LLM query without RAG
 */
export async function simpleQuery(question: string): Promise<string> {
  try {
    const prompt = `Beantworte folgende Frage prägnant und hilfreich:

${question}`;

    const answer = await callOllama(prompt);
    return answer;
  } catch (error) {
    console.error("Error in simple query:", error);
    throw error;
  }
}

/**
 * Check if Ollama is available
 */
export async function checkOllamaHealth(): Promise<boolean> {
  try {
    const response = await fetch(`${OLLAMA_BASE_URL}/api/tags`, {
      method: "GET",
    });
    return response.ok;
  } catch {
    return false;
  }
}

/**
 * Get available Ollama models
 */
export async function getAvailableModels(): Promise<string[]> {
  try {
    const response = await fetch(`${OLLAMA_BASE_URL}/api/tags`);
    const data = (await response.json()) as { models?: Array<{ name: string }> };
    return data.models?.map((m) => m.name) || [];
  } catch (error) {
    console.error("Error fetching Ollama models:", error);
    return [];
  }
}
