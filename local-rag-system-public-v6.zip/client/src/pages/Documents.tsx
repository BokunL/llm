import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Upload, Trash2, File, Clock, HardDrive, AlertCircle, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { useDocuments } from "@/contexts/DocumentContext";
import { trpc } from "@/lib/trpc";

export default function DocumentsPage() {
  const { documents, addDocument, removeDocument } = useDocuments();
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const uploadMutation = trpc.documents.upload.useMutation();

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.currentTarget.files;
    if (!files || files.length === 0) return;

    const file = files[0];
    
    // Validate file type
    const validTypes = ["application/pdf", "text/plain", "text/markdown", "application/vnd.openxmlformats-officedocument.wordprocessingml.document"];
    if (!validTypes.includes(file.type)) {
      toast.error("Nicht unterstützter Dateityp. Bitte verwenden Sie PDF, TXT oder Markdown.");
      return;
    }

    // Validate file size (max 50MB)
    const maxSize = 50 * 1024 * 1024;
    if (file.size > maxSize) {
      toast.error("Datei ist zu groß. Maximale Größe: 50MB");
      return;
    }

    setIsUploading(true);

    try {
      // Read file as base64
      const reader = new FileReader();
      reader.onload = async (event) => {
        try {
          const content = event.target?.result as string;
          const base64Content = content.split(",")[1]; // Remove data:application/pdf;base64, prefix

          // Determine file type
          let fileType: "pdf" | "txt" | "md" | "docx" = "txt";
          if (file.name.endsWith(".pdf")) fileType = "pdf";
          else if (file.name.endsWith(".md")) fileType = "md";
          else if (file.name.endsWith(".docx")) fileType = "docx";

          toast.loading("Dokument wird hochgeladen und verarbeitet...");

          // Upload via tRPC
          const result = await uploadMutation.mutateAsync({
            fileName: file.name,
            fileContent: base64Content,
            fileType,
          });

          // Add to local documents list
          const newDoc = {
            id: result.documentId,
            name: result.fileName,
            size: file.size,
            uploadedAt: new Date(),
            status: "completed" as const,
            chunks: result.chunksCreated,
          };
          
          addDocument(newDoc);
          
          toast.success(`${result.fileName} erfolgreich hochgeladen! ${result.chunksCreated} Chunks erstellt.`);
        } catch (error) {
          console.error("Upload error:", error);
          toast.error(`Fehler beim Hochladen: ${error instanceof Error ? error.message : "Unbekannter Fehler"}`);
        } finally {
          setIsUploading(false);
          if (fileInputRef.current) {
            fileInputRef.current.value = "";
          }
        }
      };
      reader.readAsDataURL(file);
    } catch (error) {
      toast.error("Fehler beim Lesen der Datei");
      setIsUploading(false);
    }
  };

  const handleDelete = async (id: number) => {
    try {
      removeDocument(id);
      toast.success("Dokument gelöscht");
    } catch (error) {
      toast.error("Fehler beim Löschen des Dokuments");
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return "0 Bytes";
    const k = 1024;
    const sizes = ["Bytes", "KB", "MB", "GB"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return Math.round((bytes / Math.pow(k, i)) * 100) / 100 + " " + sizes[i];
  };

  const formatDate = (date: Date) => {
    return new Date(date).toLocaleDateString("de-DE", {
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  return (
    <div className="space-y-6">
      {/* Upload Section */}
      <Card className="border-2 border-dashed border-border hover:border-accent/50 transition-colors">
        <CardHeader>
          <CardTitle>Dokumente hochladen</CardTitle>
          <CardDescription>
            Laden Sie PDF-, TXT- oder Markdown-Dateien hoch, um sie zu indizieren
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col items-center justify-center py-12 gap-4">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-accent/10">
              {isUploading ? (
                <Loader2 className="w-8 h-8 text-accent animate-spin" />
              ) : (
                <Upload className="w-8 h-8 text-accent" />
              )}
            </div>
            <div className="text-center">
              <p className="font-semibold text-foreground mb-1">
                Klicken Sie zum Hochladen oder ziehen Sie Dateien hierher
              </p>
              <p className="text-sm text-muted-foreground">
                Unterstützte Formate: PDF, TXT, Markdown (max. 50MB)
              </p>
            </div>
            <Button
              onClick={() => fileInputRef.current?.click()}
              disabled={isUploading}
              className="mt-4"
            >
              {isUploading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Wird hochgeladen...
                </>
              ) : (
                "Datei auswählen"
              )}
            </Button>
            <input
              ref={fileInputRef}
              type="file"
              accept=".pdf,.txt,.md,.docx"
              onChange={handleFileSelect}
              disabled={isUploading}
              className="hidden"
            />
          </div>
        </CardContent>
      </Card>

      {/* Documents List */}
      {documents.length > 0 ? (
        <div>
          <h2 className="text-lg font-semibold text-foreground mb-4">
            Hochgeladene Dokumente ({documents.length})
          </h2>
          <div className="space-y-3">
            {documents.map((doc) => (
              <Card key={doc.id} className="hover:shadow-md transition-shadow">
                <CardContent className="py-4">
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex items-start gap-4 flex-1">
                      <div className="flex-shrink-0">
                        <div className="inline-flex items-center justify-center w-10 h-10 rounded-lg bg-accent/10">
                          <File className="w-5 h-5 text-accent" />
                        </div>
                      </div>
                      <div className="flex-1 min-w-0">
                        <h3 className="font-semibold text-foreground truncate">
                          {doc.name}
                        </h3>
                        <div className="flex items-center gap-4 mt-2 text-sm text-muted-foreground flex-wrap">
                          <div className="flex items-center gap-1">
                            <HardDrive className="w-4 h-4" />
                            {formatFileSize(doc.size)}
                          </div>
                          <div className="flex items-center gap-1">
                            <Clock className="w-4 h-4" />
                            {formatDate(doc.uploadedAt)}
                          </div>
                          {doc.status === "processing" && (
                            <div className="flex items-center gap-1 text-accent">
                              <div className="w-2 h-2 rounded-full bg-accent animate-pulse" />
                              Wird verarbeitet...
                            </div>
                          )}
                          {doc.status === "completed" && (
                            <div className="text-green-600">
                              ✓ {doc.chunks} Chunks indiziert
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleDelete(doc.id)}
                      className="text-destructive hover:text-destructive hover:bg-destructive/10"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      ) : (
        <Card className="border border-dashed border-border">
          <CardContent className="py-12 text-center">
            <AlertCircle className="w-12 h-12 text-muted-foreground/50 mx-auto mb-4" />
            <p className="text-muted-foreground">
              Keine Dokumente hochgeladen. Laden Sie ein Dokument hoch, um zu beginnen.
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
